
  # Nail'd App Wireframe Guide

  This is a code bundle for Nail'd App Wireframe Guide. The original project is available at https://www.figma.com/design/aWwgphisaO2D59C60CzSmQ/Nail-d-App-Wireframe-Guide.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
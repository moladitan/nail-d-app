/**
 * Camera utility functions for accessing device camera and capturing photos
 */

export interface CameraError {
  type: 'permission_denied' | 'not_supported' | 'unknown';
  message: string;
}

/**
 * Start the device camera and return the video stream
 */
export const startCamera = async (): Promise<MediaStream> => {
  try {
    // Check if mediaDevices is supported
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      throw new Error('Camera not supported on this device');
    }

    // Request camera access (prefer back camera on mobile)
    const stream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: 'environment', // Use back camera on mobile
        width: { ideal: 1920 },
        height: { ideal: 1080 }
      },
      audio: false
    });

    return stream;
  } catch (error: any) {
    if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
      const cameraError: CameraError = {
        type: 'permission_denied',
        message: 'Camera access denied. Please allow camera permissions to continue.'
      };
      throw cameraError;
    } else if (error.name === 'NotFoundError' || error.name === 'DevicesNotFoundError') {
      const cameraError: CameraError = {
        type: 'not_supported',
        message: 'No camera found on this device.'
      };
      throw cameraError;
    } else {
      const cameraError: CameraError = {
        type: 'unknown',
        message: error.message || 'Failed to access camera'
      };
      throw cameraError;
    }
  }
};

/**
 * Stop the camera stream
 */
export const stopCamera = (stream: MediaStream): void => {
  stream.getTracks().forEach(track => track.stop());
};

/**
 * Capture a photo from the video element
 */
export const capturePhoto = (videoElement: HTMLVideoElement): string => {
  const canvas = document.createElement('canvas');
  canvas.width = videoElement.videoWidth;
  canvas.height = videoElement.videoHeight;
  
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Failed to get canvas context');
  }
  
  // Draw the current video frame to canvas
  ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
  
  // Convert to data URL (JPEG format)
  return canvas.toDataURL('image/jpeg', 0.9);
};

/**
 * Generate mock nail sizes for testing (replace with actual AI later)
 */
export const analyzeMockNailSizes = async (imageData: string): Promise<any> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 2500));
  
  // Generate random but reasonable nail sizes
  const sizes = ['XS', 'S', 'M', 'L'];
  const getRandomSize = () => sizes[Math.floor(Math.random() * sizes.length)];
  
  return {
    leftHand: {
      thumb: getRandomSize(),
      index: getRandomSize(),
      middle: getRandomSize(),
      ring: getRandomSize(),
      pinky: getRandomSize()
    },
    rightHand: {
      thumb: getRandomSize(),
      index: getRandomSize(),
      middle: getRandomSize(),
      ring: getRandomSize(),
      pinky: getRandomSize()
    }
  };
};

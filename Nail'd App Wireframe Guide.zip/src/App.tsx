import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

// Import all 14 screens
import Screen01_Splash from './components/screens/Screen01_Splash';
import Screen02_ScanInstructions from './components/screens/Screen02_ScanInstructions';
import Screen03_LiveCamera from './components/screens/Screen03_LiveCamera';
import Screen04_PhotoReview from './components/screens/Screen04_PhotoReview';
import Screen05_AdjustOutlines from './components/screens/Screen05_AdjustOutlines';
import Screen06_SizeResults from './components/screens/Screen06_SizeResults';
import Screen07_NailIDSaved from './components/screens/Screen07_NailIDSaved';
import Screen08_ChooseShape from './components/screens/Screen08_ChooseShape';
import Screen09_ChooseColor from './components/screens/Screen09_ChooseColor';
import Screen10_AddFrenchTip from './components/screens/Screen10_AddFrenchTip';
import Screen11_Cart from './components/screens/Screen11_Cart';
import Screen12_ShippingInfo from './components/screens/Screen12_ShippingInfo';
import Screen13_Payment from './components/screens/Screen13_Payment';
import Screen14_OrderConfirmation from './components/screens/Screen14_OrderConfirmation';

type Screen = 
  | 'splash'
  | 'scanInstructions'
  | 'liveCamera'
  | 'photoReview'
  | 'adjustOutlines'
  | 'sizeResults'
  | 'nailIDSaved'
  | 'chooseShape'
  | 'chooseColor'
  | 'addFrenchTip'
  | 'cart'
  | 'shippingInfo'
  | 'payment'
  | 'orderConfirmation';

interface Design {
  shape: string;
  color: string;
  colorName: string;
  hasFrenchTip: boolean;
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('splash');
  const [screenHistory, setScreenHistory] = useState<Screen[]>(['splash']);
  const [design, setDesign] = useState<Design>({
    shape: 'Almond',
    color: '#C4536C',
    colorName: 'Deep Rose',
    hasFrenchTip: false
  });
  
  // Store captured photo and nail sizes
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [nailSizes, setNailSizes] = useState<any>(null);

  const navigateTo = (screen: Screen) => {
    setScreenHistory(prev => [...prev, screen]);
    setCurrentScreen(screen);
  };

  const navigateBack = () => {
    if (screenHistory.length > 1) {
      const newHistory = screenHistory.slice(0, -1);
      setScreenHistory(newHistory);
      setCurrentScreen(newHistory[newHistory.length - 1]);
    }
  };

  const screenVariants = {
    initial: { opacity: 0, x: 20 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: -20 }
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'splash':
        return (
          <Screen01_Splash
            onGetStarted={() => navigateTo('scanInstructions')}
            onLogin={() => navigateTo('chooseShape')}
          />
        );
      
      case 'scanInstructions':
        return (
          <Screen02_ScanInstructions
            onOpenCamera={() => navigateTo('liveCamera')}
            onBack={navigateBack}
          />
        );
      
      case 'liveCamera':
        return (
          <Screen03_LiveCamera
            onCapture={(photoData) => {
              setCapturedPhoto(photoData);
              navigateTo('photoReview');
            }}
            onBack={navigateBack}
          />
        );
      
      case 'photoReview':
        return (
          <Screen04_PhotoReview
            capturedPhoto={capturedPhoto}
            onRetake={() => navigateTo('liveCamera')}
            onAnalyze={() => navigateTo('adjustOutlines')}
            onBack={navigateBack}
          />
        );
      
      case 'adjustOutlines':
        return (
          <Screen05_AdjustOutlines
            capturedPhoto={capturedPhoto}
            onConfirm={(sizes) => {
              setNailSizes(sizes);
              navigateTo('sizeResults');
            }}
            onBack={navigateBack}
          />
        );
      
      case 'sizeResults':
        return (
          <Screen06_SizeResults
            nailSizes={nailSizes}
            onSave={() => navigateTo('nailIDSaved')}
            onRescan={() => navigateTo('scanInstructions')}
            onBack={navigateBack}
          />
        );
      
      case 'nailIDSaved':
        return (
          <Screen07_NailIDSaved
            onStartDesigning={() => navigateTo('chooseShape')}
          />
        );
      
      case 'chooseShape':
        return (
          <Screen08_ChooseShape
            onNext={(shape) => {
              setDesign(prev => ({ ...prev, shape }));
              navigateTo('chooseColor');
            }}
            onBack={navigateBack}
          />
        );
      
      case 'chooseColor':
        return (
          <Screen09_ChooseColor
            shape={design.shape}
            onNext={(color, colorName) => {
              setDesign(prev => ({ ...prev, color, colorName }));
              navigateTo('addFrenchTip');
            }}
            onBack={navigateBack}
          />
        );
      
      case 'addFrenchTip':
        return (
          <Screen10_AddFrenchTip
            shape={design.shape}
            color={design.color}
            colorName={design.colorName}
            onSaveCheckout={(hasFrenchTip) => {
              setDesign(prev => ({ ...prev, hasFrenchTip }));
              navigateTo('cart');
            }}
            onBack={navigateBack}
          />
        );
      
      case 'cart':
        return (
          <Screen11_Cart
            shape={design.shape}
            color={design.color}
            colorName={design.colorName}
            hasFrenchTip={design.hasFrenchTip}
            onProceedCheckout={() => navigateTo('shippingInfo')}
            onBack={navigateBack}
          />
        );
      
      case 'shippingInfo':
        return (
          <Screen12_ShippingInfo
            onContinuePayment={() => navigateTo('payment')}
            onBack={navigateBack}
          />
        );
      
      case 'payment':
        return (
          <Screen13_Payment
            total={28}
            design={design}
            onPlaceOrder={() => navigateTo('orderConfirmation')}
            onBack={navigateBack}
          />
        );
      
      case 'orderConfirmation':
        return (
          <Screen14_OrderConfirmation
            design={design}
            onTrackOrder={() => navigateTo('chooseShape')}
            onViewGuide={() => navigateTo('chooseShape')}
            onShopAgain={() => navigateTo('chooseShape')}
          />
        );
      
      default:
        return <Screen01_Splash onGetStarted={() => navigateTo('scanInstructions')} onLogin={() => navigateTo('chooseShape')} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      {/* iPhone 16 frame */}
      <div className="relative" style={{ width: '393px', height: '852px' }}>
        <div className="absolute inset-0 rounded-[60px] bg-gradient-to-b from-gray-900 to-black shadow-2xl" style={{ padding: '12px' }}>
          <div className="w-full h-full rounded-[48px] overflow-hidden bg-white relative">
            <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-40 h-8 bg-black rounded-b-3xl z-50" />
            
            <AnimatePresence mode="wait">
              <motion.div
                key={currentScreen}
                variants={screenVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                className="w-full h-full"
              >
                {renderScreen()}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}

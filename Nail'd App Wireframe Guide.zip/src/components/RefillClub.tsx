import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Sparkles, Calendar, Palette, Gift } from 'lucide-react';

interface RefillClubProps {
  onJoin: () => void;
  onSkip: () => void;
}

const cards = [
  {
    icon: Calendar,
    title: 'Monthly Refills',
    description: 'Fresh designs auto-matched to your Fit ID.',
    color: '#FCA3BA',
  },
  {
    icon: Palette,
    title: 'Choose Your Vibe',
    description: 'Minimalist / Bold / Trendy.',
    color: '#E84D7E',
  },
  {
    icon: Gift,
    title: 'Perks & Surprises',
    description: 'Eco packaging. Easy swaps. Free gifts.',
    color: '#C4536C',
  },
];

export default function RefillClub({ onJoin, onSkip }: RefillClubProps) {
  const [currentCard, setCurrentCard] = useState(0);

  const nextCard = () => {
    setCurrentCard((prev) => (prev + 1) % cards.length);
  };

  const prevCard = () => {
    setCurrentCard((prev) => (prev - 1 + cards.length) % cards.length);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-[#FEEBEC] to-[#FCEFE5] px-6 py-8 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(10)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -25, 0],
              opacity: [0.2, 0.6, 0.2],
              scale: [0.8, 1.2, 0.8],
            }}
            transition={{
              duration: 3.5 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          >
            <Sparkles className="text-[#FFD9A5]/50" size={14 + Math.random() * 16} />
          </motion.div>
        ))}
      </div>

      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="text-center mb-10 mt-6 relative z-10"
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", delay: 0.2, stiffness: 150, damping: 15 }}
          className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-[#FFD9A5] via-[#FCA3BA] to-[#E84D7E] rounded-full mb-5 shadow-[0_10px_40px_rgba(252,163,186,0.4)]"
        >
          <Sparkles className="text-white" size={32} />
        </motion.div>
        <h1 className="text-3xl text-[#C4536C] mb-3" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
          Join Nail'd Club
        </h1>
        <p className="text-[#A05C6E] text-base" style={{ fontFamily: 'Nunito, sans-serif' }}>
          Never run out of fresh styles
        </p>
      </motion.div>

      {/* Carousel */}
      <div className="flex-1 flex items-center justify-center relative">
        <motion.button
          onClick={prevCard}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          className="absolute left-0 z-10 bg-white/70 backdrop-blur-md rounded-full p-3 shadow-lg hover:bg-white/90 transition-colors"
        >
          <ChevronLeft className="text-[#C4536C]" size={24} strokeWidth={2.5} />
        </motion.button>

        <div className="w-full max-w-sm mx-14">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentCard}
              initial={{ opacity: 0, x: 100, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: -100, scale: 0.9 }}
              transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              className="bg-white/80 backdrop-blur-md rounded-3xl p-9 shadow-[0_10px_60px_rgba(196,83,108,0.15)] border border-[#FCA3BA]/30 relative overflow-hidden"
            >
              {/* Background gradient accent */}
              <div
                className="absolute top-0 right-0 w-40 h-40 rounded-full blur-3xl opacity-20"
                style={{ backgroundColor: cards[currentCard].color }}
              />

              <div className="relative z-10">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring" }}
                  className="w-20 h-20 rounded-full flex items-center justify-center mb-6 mx-auto shadow-lg"
                  style={{ backgroundColor: `${cards[currentCard].color}25` }}
                >
                  {(() => {
                    const IconComponent = cards[currentCard].icon;
                    return IconComponent ? (
                      <IconComponent
                        size={36}
                        strokeWidth={2}
                        style={{ color: cards[currentCard].color }}
                      />
                    ) : null;
                  })()}
                </motion.div>

                <h3 className="text-2xl text-[#C4536C] text-center mb-5" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
                  {cards[currentCard].title}
                </h3>

                <p className="text-[#A05C6E] text-center text-base leading-relaxed" style={{ fontFamily: 'Nunito, sans-serif' }}>
                  {cards[currentCard].description}
                </p>
              </div>

              {/* Sparkle animation on card */}
              {currentCard === 1 && (
                <motion.div
                  className="absolute bottom-4 right-4"
                  animate={{
                    rotate: [0, 15, -15, 0],
                    scale: [1, 1.2, 1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                  }}
                >
                  <Sparkles className="text-[#FFD9A5]" size={28} />
                </motion.div>
              )}
            </motion.div>
          </AnimatePresence>

          {/* Dots indicator */}
          <div className="flex justify-center gap-2.5 mt-8">
            {cards.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentCard(index)}
                className={`h-2.5 rounded-full transition-all ${
                  index === currentCard
                    ? 'w-10 bg-[#E84D7E] shadow-[0_2px_10px_rgba(232,77,126,0.4)]'
                    : 'w-2.5 bg-[#C4536C]/30 hover:bg-[#C4536C]/50'
                }`}
              />
            ))}
          </div>
        </div>

        <motion.button
          onClick={nextCard}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          className="absolute right-0 z-10 bg-white/70 backdrop-blur-md rounded-full p-3 shadow-lg hover:bg-white/90 transition-colors"
        >
          <ChevronRight className="text-[#C4536C]" size={24} strokeWidth={2.5} />
        </motion.button>
      </div>

      {/* CTAs */}
      <div className="w-full max-w-md mx-auto space-y-4 mt-12 relative z-10">
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          whileHover={{ scale: 1.02, boxShadow: "0 8px 32px rgba(232,77,126,0.45)" }}
          whileTap={{ scale: 0.98 }}
          onClick={onJoin}
          className="w-full bg-gradient-to-r from-[#FCA3BA] to-[#E84D7E] text-white py-5 rounded-2xl shadow-[0_6px_24px_rgba(232,77,126,0.35)] transition-all"
          style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700, letterSpacing: '0.02em' }}
        >
          Join the Club →
        </motion.button>

        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          onClick={onSkip}
          className="w-full text-[#C4536C] py-3 hover:text-[#E84D7E] transition-colors"
          style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}
        >
          Maybe later
        </motion.button>
      </div>
    </div>
  );
}
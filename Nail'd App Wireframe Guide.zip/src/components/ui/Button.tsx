import { motion } from 'motion/react';
import { ReactNode } from 'react';

interface ButtonProps {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary';
  fullWidth?: boolean;
  disabled?: boolean;
}

export default function Button({
  children,
  onClick,
  variant = 'primary',
  fullWidth = true,
  disabled = false
}: ButtonProps) {
  const baseClasses = "h-14 rounded-[14px] transition-all";
  
  const variantClasses = {
    primary: "bg-[#C4536C] text-white shadow-[0_2px_12px_rgba(196,83,108,0.3)]",
    secondary: "bg-transparent border-2 border-[#C4536C] text-[#C4536C]"
  };
  
  const widthClass = fullWidth ? "w-full" : "px-8";
  
  return (
    <motion.button
      whileHover={{ scale: disabled ? 1 : 1.01 }}
      whileTap={{ scale: disabled ? 1 : 0.98 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      onClick={onClick}
      disabled={disabled}
      className={`${baseClasses} ${variantClasses[variant]} ${widthClass} ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 600, fontSize: '16px' }}
    >
      {children}
    </motion.button>
  );
}

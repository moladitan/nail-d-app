import { InputHTMLAttributes } from 'react';

interface FormInputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
}

export default function FormInput({ label, ...props }: FormInputProps) {
  return (
    <div className="space-y-2">
      {label && (
        <label className="block text-sm text-[#C4536C]/70" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 500 }}>
          {label}
        </label>
      )}
      <input
        {...props}
        className="w-full h-14 px-4 rounded-xl border border-[#F0E0E8] bg-white focus:border-[#FCA3BA] outline-none transition-colors"
        style={{ fontFamily: 'Nunito, sans-serif', fontSize: '16px' }}
      />
    </div>
  );
}

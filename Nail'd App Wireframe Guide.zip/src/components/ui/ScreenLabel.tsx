interface ScreenLabelProps {
  label: string;
}

export default function ScreenLabel({ label }: ScreenLabelProps) {
  return (
    <div className="text-center py-3">
      <p className="text-xs text-gray-400" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 500 }}>
        {label}
      </p>
    </div>
  );
}

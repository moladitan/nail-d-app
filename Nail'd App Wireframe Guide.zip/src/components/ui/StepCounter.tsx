interface StepCounterProps {
  current: number;
  total: number;
}

export default function StepCounter({ current, total }: StepCounterProps) {
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="flex items-center gap-2">
        {[...Array(total)].map((_, i) => (
          <div
            key={i}
            className={`w-2 h-2 rounded-full transition-all ${
              i < current
                ? 'bg-[#C4536C]'
                : i === current
                ? 'w-6 bg-[#C4536C]'
                : 'bg-gray-300'
            }`}
          />
        ))}
      </div>
      <p className="text-xs text-[#C4536C]/70" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
        Step {current + 1} of {total}
      </p>
    </div>
  );
}

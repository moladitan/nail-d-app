interface SummaryCardProps {
  shape: string;
  color: string;
  colorName: string;
  hasFrenchTip: boolean;
}

export default function SummaryCard({ shape, color, colorName, hasFrenchTip }: SummaryCardProps) {
  return (
    <div className="bg-white rounded-2xl p-6 shadow-[0_2px_8px_rgba(0,0,0,0.08)]">
      <h3 className="text-base mb-4 text-[#C4536C]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
        Your custom set
      </h3>
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-[#C4536C]/60" style={{ fontFamily: 'Nunito, sans-serif' }}>
            Shape:
          </span>
          <span className="text-sm text-[#C4536C]" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
            {shape}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-[#C4536C]/60" style={{ fontFamily: 'Nunito, sans-serif' }}>
            Color:
          </span>
          <div className="flex items-center gap-2">
            <div 
              className="w-4 h-4 rounded-full border border-[#C4536C]/20"
              style={{ backgroundColor: color }}
            />
            <span className="text-sm text-[#C4536C]" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
              {colorName}
            </span>
          </div>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-[#C4536C]/60" style={{ fontFamily: 'Nunito, sans-serif' }}>
            French tip:
          </span>
          <span className="text-sm text-[#C4536C]" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
            {hasFrenchTip ? 'Classic white' : 'None'}
          </span>
        </div>
      </div>
    </div>
  );
}

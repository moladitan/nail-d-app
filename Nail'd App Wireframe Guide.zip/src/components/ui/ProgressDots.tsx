interface ProgressDotsProps {
  total: number;
  current: number;
}

export default function ProgressDots({ total, current }: ProgressDotsProps) {
  return (
    <div className="flex items-center justify-center gap-2">
      {[...Array(total)].map((_, i) => (
        <div
          key={i}
          className={`h-1.5 rounded-full transition-all ${
            i === current
              ? 'w-6 bg-[#C4536C]'
              : i < current
              ? 'w-1.5 bg-[#C4536C]/40'
              : 'w-1.5 bg-[#C4536C]/20'
          }`}
        />
      ))}
    </div>
  );
}

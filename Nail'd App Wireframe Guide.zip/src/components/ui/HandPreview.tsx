import { motion } from 'motion/react';
import { useEffect, useRef } from 'react';

interface HandPreviewProps {
  color: string;
  shape: string;
  hasFrenchTip: boolean;
  imageUrl: string;
}

export default function HandPreview({ color, shape, hasFrenchTip, imageUrl }: HandPreviewProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = imageUrl;

    img.onload = () => {
      // Set canvas size to match image
      canvas.width = img.width;
      canvas.height = img.height;

      // Draw the hand image
      ctx.drawImage(img, 0, 0);

      // Draw nail overlays
      drawNailOverlays(ctx, canvas.width, canvas.height, color, shape, hasFrenchTip);
    };
  }, [color, shape, hasFrenchTip, imageUrl]);

  return (
    <motion.div
      key={`${color}-${shape}-${hasFrenchTip}`}
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      className="relative w-full rounded-3xl overflow-hidden shadow-2xl"
    >
      <canvas
        ref={canvasRef}
        className="w-full h-auto"
        style={{ display: 'block' }}
      />
    </motion.div>
  );
}

function drawNailOverlays(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  color: string,
  shape: string,
  hasFrenchTip: boolean
) {
  // Define nail positions (percentages of canvas size)
  const nailPositions = [
    { x: 0.25, y: 0.35, width: 0.08, height: 0.12 }, // Thumb
    { x: 0.35, y: 0.25, width: 0.06, height: 0.15 }, // Index
    { x: 0.45, y: 0.20, width: 0.06, height: 0.16 }, // Middle
    { x: 0.55, y: 0.23, width: 0.06, height: 0.15 }, // Ring
    { x: 0.65, y: 0.30, width: 0.05, height: 0.12 }  // Pinky
  ];

  nailPositions.forEach(nail => {
    const x = nail.x * width;
    const y = nail.y * height;
    const w = nail.width * width;
    const h = nail.height * height;

    // Set nail color with transparency
    ctx.fillStyle = color;
    ctx.globalAlpha = 0.7;

    // Draw nail shape
    ctx.beginPath();
    if (shape === 'Almond' || shape === 'Oval') {
      // Rounded top
      ctx.ellipse(x + w / 2, y + h * 0.3, w / 2, h * 0.3, 0, 0, Math.PI * 2);
      ctx.rect(x, y + h * 0.3, w, h * 0.7);
    } else if (shape === 'Coffin') {
      // Tapered top
      ctx.moveTo(x, y + h);
      ctx.lineTo(x + w * 0.2, y);
      ctx.lineTo(x + w * 0.8, y);
      ctx.lineTo(x + w, y + h);
    } else {
      // Square
      ctx.rect(x, y, w, h);
    }
    ctx.fill();

    // Draw French tip if enabled
    if (hasFrenchTip) {
      ctx.fillStyle = '#ffffff';
      ctx.globalAlpha = 0.8;
      ctx.beginPath();
      if (shape === 'Almond' || shape === 'Oval') {
        ctx.ellipse(x + w / 2, y + h * 0.15, w / 2, h * 0.15, 0, 0, Math.PI * 2);
      } else {
        ctx.rect(x, y, w, h * 0.25);
      }
      ctx.fill();
    }

    ctx.globalAlpha = 1.0;
  });
}

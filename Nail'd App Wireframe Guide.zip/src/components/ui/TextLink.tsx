import { motion } from 'motion/react';

interface TextLinkProps {
  children: React.ReactNode;
  onClick?: () => void;
}

export default function TextLink({ children, onClick }: TextLinkProps) {
  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="text-[#C4536C] underline text-sm"
      style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}
    >
      {children}
    </motion.button>
  );
}

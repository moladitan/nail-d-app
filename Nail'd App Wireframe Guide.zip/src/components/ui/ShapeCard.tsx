import { motion } from 'motion/react';
import { ReactNode } from 'react';

interface ShapeCardProps {
  icon: ReactNode;
  label: string;
  selected?: boolean;
  onClick: () => void;
}

export default function ShapeCard({ icon, label, selected = false, onClick }: ShapeCardProps) {
  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`w-full h-20 rounded-xl flex items-center justify-center gap-3 transition-all ${
        selected
          ? 'bg-[#C4536C] text-white shadow-[0_2px_12px_rgba(196,83,108,0.3)]'
          : 'bg-white text-[#FCA3BA] border border-[#F0E0E8]'
      }`}
      style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600, fontSize: '16px' }}
    >
      <span className="text-2xl">{icon}</span>
      {label}
    </motion.button>
  );
}

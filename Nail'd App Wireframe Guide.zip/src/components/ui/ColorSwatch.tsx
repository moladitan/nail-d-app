import { motion } from 'motion/react';
import { Check } from 'lucide-react';

interface ColorSwatchProps {
  color: string;
  label: string;
  selected?: boolean;
  onClick: () => void;
}

export default function ColorSwatch({ color, label, selected = false, onClick }: ColorSwatchProps) {
  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className="flex flex-col items-center gap-3"
    >
      <div className="relative">
        <div
          className={`w-16 h-16 rounded-full transition-all ${
            selected ? 'ring-4 ring-white ring-offset-2' : ''
          }`}
          style={{ backgroundColor: color, boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}
        />
        {selected && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 300, damping: 20 }}
            className="absolute inset-0 flex items-center justify-center"
          >
            <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center shadow-lg">
              <Check size={14} className="text-[#C4536C]" strokeWidth={3} />
            </div>
          </motion.div>
        )}
      </div>
      <span
        className={`text-sm ${selected ? 'text-[#C4536C]' : 'text-[#C4536C]/60'}`}
        style={{ fontFamily: 'Nunito, sans-serif', fontWeight: selected ? 600 : 500 }}
      >
        {label}
      </span>
    </motion.button>
  );
}

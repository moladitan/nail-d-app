import { motion } from 'motion/react';
import { Ruler, Sparkles, CircleDot, Maximize2, Check } from 'lucide-react';

interface FitIDResultsProps {
  fitID: {
    width: string;
    curve: string;
    shape: string;
    length: string;
  };
  onNext: () => void;
}

export default function FitIDResults({ fitID, onNext }: FitIDResultsProps) {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-[#FEEBEC] to-[#FCEFE5] px-6 py-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="text-center mb-8 mt-6"
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", delay: 0.2, stiffness: 150, damping: 15 }}
          className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-[#FCA3BA] via-[#E84D7E] to-[#C4536C] rounded-full mb-5 shadow-[0_10px_40px_rgba(232,77,126,0.35)]"
        >
          <Check className="text-white" size={36} strokeWidth={3.5} />
        </motion.div>
        <h1 className="text-3xl text-[#C4536C] mb-3" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
          Scan Complete!
        </h1>
        <p className="text-[#A05C6E] text-base" style={{ fontFamily: 'Nunito, sans-serif' }}>
          Your custom Fit ID is ready
        </p>
      </motion.div>

      {/* Results Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
        className="flex-1 flex items-start justify-center w-full"
      >
        <div className="bg-white/90 backdrop-blur-md rounded-3xl p-7 shadow-[0_10px_60px_rgba(196,83,108,0.15)] border border-[#FCA3BA]/30 max-w-md w-full">
          <div className="space-y-5">
            {/* Width */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              className="flex items-start gap-4 p-5 bg-gradient-to-r from-[#FEEBEC] to-white rounded-2xl shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="bg-gradient-to-br from-[#FCA3BA] to-[#E84D7E] p-3.5 rounded-xl shadow-lg">
                <Ruler className="text-white" size={22} />
              </div>
              <div className="flex-1">
                <p className="text-[#C4536C] text-sm mb-1.5" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 600 }}>
                  Nail Width
                </p>
                <p className="text-[#A05C6E] text-base" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
                  {fitID.width}
                </p>
              </div>
            </motion.div>

            {/* Curve */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              className="flex items-start gap-4 p-5 bg-gradient-to-r from-[#FEEBEC] to-white rounded-2xl shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="bg-gradient-to-br from-[#FCA3BA] to-[#E84D7E] p-3.5 rounded-xl shadow-lg">
                <CircleDot className="text-white" size={22} />
              </div>
              <div className="flex-1">
                <p className="text-[#C4536C] text-sm mb-1.5" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 600 }}>
                  Curve Profile
                </p>
                <p className="text-[#A05C6E] text-base" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
                  {fitID.curve}
                </p>
              </div>
            </motion.div>

            {/* Shape */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.7, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              className="flex items-start gap-4 p-5 bg-gradient-to-r from-[#FEEBEC] to-white rounded-2xl shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="bg-gradient-to-br from-[#FFD9A5] to-[#FCA3BA] p-3.5 rounded-xl shadow-lg">
                <Sparkles className="text-white" size={22} />
              </div>
              <div className="flex-1">
                <p className="text-[#C4536C] text-sm mb-1.5" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 600 }}>
                  Nail Shape
                </p>
                <p className="text-[#A05C6E] text-base" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
                  {fitID.shape}
                </p>
              </div>
            </motion.div>

            {/* Length */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.8, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              className="flex items-start gap-4 p-5 bg-gradient-to-r from-[#FEEBEC] to-white rounded-2xl shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="bg-gradient-to-br from-[#FCA3BA] to-[#E84D7E] p-3.5 rounded-xl shadow-lg">
                <Maximize2 className="text-white" size={22} />
              </div>
              <div className="flex-1">
                <p className="text-[#C4536C] text-sm mb-1.5" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 600 }}>
                  Nail Length
                </p>
                <p className="text-[#A05C6E] text-base" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
                  {fitID.length}
                </p>
              </div>
            </motion.div>
          </div>

          {/* Info badge */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9, duration: 0.6 }}
            className="mt-6 p-4 bg-gradient-to-r from-[#FFD9A5]/40 to-[#FCA3BA]/30 rounded-2xl border border-[#FCA3BA]/40 shadow-sm"
          >
            <p className="text-[#C4536C] text-sm text-center leading-relaxed" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 500 }}>
              ✨ Your Fit ID is saved for all future orders
            </p>
          </motion.div>
        </div>
      </motion.div>

      {/* CTA */}
      <div className="w-full max-w-md mx-auto space-y-3 mt-8">
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.6 }}
          whileHover={{ scale: 1.02, boxShadow: "0 8px 32px rgba(232,77,126,0.45)" }}
          whileTap={{ scale: 0.98 }}
          onClick={onNext}
          className="w-full bg-gradient-to-r from-[#FCA3BA] to-[#E84D7E] text-white py-5 rounded-2xl shadow-[0_6px_24px_rgba(232,77,126,0.35)] transition-all"
          style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700, letterSpacing: '0.02em' }}
        >
          Continue to Design
        </motion.button>
      </div>
    </div>
  );
}
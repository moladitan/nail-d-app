import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Heart, Sparkles } from 'lucide-react';

interface CustomizationProps {
  fitID: {
    width: string;
    curve: string;
    shape: string;
    length: string;
  };
  selectedDesign: {
    color: string;
    finish: string;
    colorName: string;
  };
  setSelectedDesign: (design: any) => void;
  onNext: () => void;
  onBack: () => void;
}

const colorOptions = [
  { color: '#C4536C', name: 'Rose Blush', finish: 'Glossy' },
  { color: '#FFB6C1', name: 'Pink Pearl', finish: 'Glossy' },
  { color: '#E84D7E', name: 'Deep Rose', finish: 'Matte' },
  { color: '#FCA3BA', name: 'Peach Glow', finish: 'Glossy' },
  { color: '#8B4C5C', name: 'Berry Wine', finish: 'Matte' },
  { color: '#FFD9E8', name: 'Soft Pink', finish: 'Chrome' },
  { color: '#A05C6E', name: 'Mauve Taupe', finish: 'Matte' },
  { color: '#FF69B4', name: 'Hot Pink', finish: 'Chrome' },
];

export default function Customization({
  fitID,
  selectedDesign,
  setSelectedDesign,
  onNext,
  onBack,
}: CustomizationProps) {
  const [isFavorite, setIsFavorite] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FEEBEC] to-[#FCEFE5]">
      {/* Top Navigation */}
      <div className="flex items-center justify-between px-6 py-5 bg-white/70 backdrop-blur-xl border-b border-[#FCA3BA]/30 shadow-sm">
        <motion.button 
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onBack} 
          className="p-2.5 hover:bg-[#FCA3BA]/15 rounded-full transition-colors"
        >
          <ArrowLeft size={24} className="text-[#C4536C]" strokeWidth={2.5} />
        </motion.button>
        <h1 className="text-xl text-[#C4536C]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
          Nail Studio
        </h1>
        <motion.button 
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsFavorite(!isFavorite)}
          className="p-2.5 hover:bg-[#FCA3BA]/15 rounded-full transition-colors"
        >
          <Heart 
            size={24} 
            className="text-[#C4536C] transition-all" 
            strokeWidth={2.5}
            fill={isFavorite ? '#C4536C' : 'none'} 
          />
        </motion.button>
      </div>

      {/* 3D Hand Mockup */}
      <div className="px-6 py-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <div className="relative bg-white/50 backdrop-blur-sm rounded-3xl p-6 shadow-xl border border-[#FCA3BA]/20 flex items-center justify-center min-h-[320px]">
            {/* Simplified hand illustration with nail colors */}
            <svg width="240" height="300" viewBox="0 0 280 340" className="drop-shadow-2xl">
              <defs>
                <filter id="nailGlow">
                  <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                  <feMerge>
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>
              </defs>

              {/* Palm - skin tone */}
              <ellipse cx="140" cy="240" rx="80" ry="100" fill="#FCDCCC" stroke="#D4A59A" strokeWidth="2" opacity="0.95" />
              
              {/* Thumb */}
              <ellipse cx="70" cy="220" rx="26" ry="50" fill="#FCDCCC" stroke="#D4A59A" strokeWidth="2" opacity="0.95" />
              <ellipse cx="70" cy="190" rx="12" ry="18" fill={selectedDesign.color} stroke="#8B4C5C" strokeWidth="1.5" filter="url(#nailGlow)" />
              
              {/* Index finger */}
              <rect x="95" y="100" width="26" height="140" rx="13" fill="#FCDCCC" stroke="#D4A59A" strokeWidth="2" opacity="0.95" />
              <ellipse cx="108" cy="100" rx="11" ry="20" fill={selectedDesign.color} stroke="#8B4C5C" strokeWidth="1.5" filter="url(#nailGlow)" />
              
              {/* Middle finger */}
              <rect x="130" y="70" width="28" height="170" rx="14" fill="#FCDCCC" stroke="#D4A59A" strokeWidth="2" opacity="0.95" />
              <ellipse cx="144" cy="70" rx="12" ry="22" fill={selectedDesign.color} stroke="#8B4C5C" strokeWidth="1.5" filter="url(#nailGlow)" />
              
              {/* Ring finger */}
              <rect x="165" y="100" width="26" height="140" rx="13" fill="#FCDCCC" stroke="#D4A59A" strokeWidth="2" opacity="0.95" />
              <ellipse cx="178" cy="100" rx="11" ry="20" fill={selectedDesign.color} stroke="#8B4C5C" strokeWidth="1.5" filter="url(#nailGlow)" />
              
              {/* Pinky */}
              <rect x="198" y="130" width="24" height="110" rx="12" fill="#FCDCCC" stroke="#D4A59A" strokeWidth="2" opacity="0.95" />
              <ellipse cx="210" cy="130" rx="10" ry="18" fill={selectedDesign.color} stroke="#8B4C5C" strokeWidth="1.5" filter="url(#nailGlow)" />
            </svg>

            {/* Floating sparkles */}
            <motion.div
              className="absolute top-4 right-4"
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.5, 1, 0.5],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              <Sparkles className="text-[#FFD9A5]" size={20} />
            </motion.div>
          </div>

          {/* Current Selection Info */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mt-4 bg-white/70 backdrop-blur-sm rounded-2xl p-4 border border-[#FCA3BA]/20 shadow-md"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[#C4536C] text-sm mb-1" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 600 }}>
                  {selectedDesign.colorName}
                </p>
                <p className="text-[#A05C6E] text-xs" style={{ fontFamily: 'Nunito, sans-serif' }}>
                  {selectedDesign.finish} Finish • {fitID.shape}
                </p>
              </div>
              <div 
                className="w-12 h-12 rounded-full shadow-lg border-2 border-white"
                style={{ backgroundColor: selectedDesign.color }}
              />
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Color Swatches */}
      <div className="px-6 pb-6">
        <h2 className="text-[#C4536C] mb-4 text-sm" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 600 }}>
          Choose Color & Finish
        </h2>
        <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
          {colorOptions.map((option, index) => (
            <motion.button
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 + index * 0.05 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedDesign(option)}
              className={`flex-shrink-0 flex flex-col items-center gap-2 transition-transform ${
                selectedDesign.color === option.color ? 'scale-110' : ''
              }`}
            >
              <div className="relative">
                <div
                  className={`w-14 h-14 rounded-full border-3 transition-all ${
                    selectedDesign.color === option.color
                      ? 'border-[#E84D7E] shadow-[0_0_20px_rgba(232,77,126,0.5)]'
                      : 'border-white/80 shadow-md'
                  }`}
                  style={{ backgroundColor: option.color }}
                />
                {selectedDesign.color === option.color && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-1 -right-1 w-5 h-5 bg-[#E84D7E] rounded-full flex items-center justify-center shadow-lg"
                  >
                    <span className="text-white text-xs">✓</span>
                  </motion.div>
                )}
              </div>
              <div className="text-center w-16">
                <span className="text-xs text-[#A05C6E] block leading-tight" style={{ fontFamily: 'Nunito, sans-serif' }}>
                  {option.name}
                </span>
                <span className="text-xs text-[#C4536C]/60 block" style={{ fontFamily: 'Nunito, sans-serif' }}>
                  {option.finish}
                </span>
              </div>
            </motion.button>
          ))}
        </div>
      </div>

      {/* CTA Button */}
      <div className="px-6 pb-6">
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={onNext}
          className="w-full bg-gradient-to-r from-[#FCA3BA] to-[#E84D7E] text-white py-4 rounded-2xl shadow-[0_4px_20px_rgba(232,77,126,0.3)] hover:shadow-[0_6px_28px_rgba(232,77,126,0.4)] transition-all"
          style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 600 }}
        >
          Apply This Style
        </motion.button>
      </div>
    </div>
  );
}
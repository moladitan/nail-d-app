import { motion } from 'motion/react';
import { useState } from 'react';
import Button from '../ui/Button';
import SummaryCard from '../ui/SummaryCard';
import BackButton from '../ui/BackButton';
import StepCounter from '../ui/StepCounter';
import ScreenLabel from '../ui/ScreenLabel';
import HandPreview from '../ui/HandPreview';

interface Screen10Props {
  shape: string;
  color: string;
  colorName: string;
  onSaveCheckout: (hasFrenchTip: boolean) => void;
  onBack: () => void;
}

export default function Screen10_AddFrenchTip({ shape, color, colorName, onSaveCheckout, onBack }: Screen10Props) {
  const [frenchTip, setFrenchTip] = useState(false);
  
  const handImageUrl = "https://images.unsplash.com/photo-1741886419563-681e5da31b2c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMGhhbmQlMjBuYWlscyUyMG1hbmljdXJlJTIwdG9wJTIwdmlld3xlbnwxfHx8fDE3Njk3ODU5NjN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral";

  return (
    <div 
      className="min-h-screen overflow-y-auto bg-[#FCEFE5] px-6 py-8" 
      style={{ height: '852px', width: '393px', margin: '0 auto' }}
    >
      <div className="h-4" />
      
      <div className="flex items-center justify-between mb-6">
        <BackButton onClick={onBack} />
        <StepCounter current={5} total={7} />
        <div className="w-10" />
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-2xl mb-1 text-[#C4536C]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
          Nail Studio
        </h1>
        <p className="text-base text-[#C4536C]/70 mb-8" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 500 }}>
          Finalize your set
        </p>

        <div className="mb-6">
          <HandPreview 
            color={color}
            shape={shape}
            hasFrenchTip={frenchTip}
            imageUrl={handImageUrl}
          />
        </div>

        <h2 className="text-sm text-[#C4536C] mb-4" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 700, letterSpacing: '0.5px' }}>
          ADD FRENCH TIP
        </h2>

        <div className="flex gap-3 mb-6">
          {['Yes', 'No'].map((option) => (
            <button
              key={option}
              onClick={() => setFrenchTip(option === 'Yes')}
              className={`flex-1 h-14 rounded-xl transition-all ${
                (option === 'Yes' && frenchTip) || (option === 'No' && !frenchTip)
                  ? 'bg-[#C4536C] text-white shadow-[0_2px_12px_rgba(196,83,108,0.3)]'
                  : 'bg-white text-[#FCA3BA] border border-[#F0E0E8]'
              }`}
              style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}
            >
              {option}
            </button>
          ))}
        </div>

        {frenchTip && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="bg-[#FFD9A5]/20 rounded-2xl p-4 mb-8 text-center"
          >
            <p className="text-sm text-[#C4536C]" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
              ✨ Classic white tip selected
            </p>
          </motion.div>
        )}

        <div className="mb-8">
          <SummaryCard
            shape={shape}
            color={color}
            colorName={colorName}
            hasFrenchTip={frenchTip}
          />
        </div>

        <Button onClick={() => onSaveCheckout(frenchTip)} variant="primary">
          Save & checkout
        </Button>
      </motion.div>
      
      <ScreenLabel label="Nail Studio - Add French Tip" />
    </div>
  );
}
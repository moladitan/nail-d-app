import { motion } from 'motion/react';
import Button from '../ui/Button';
import TextLink from '../ui/TextLink';
import ScreenLabel from '../ui/ScreenLabel';
import logoImage from 'figma:asset/f4ebe04187e1e9fce3c04bbc6dd8c71426601b82.png';

interface Screen01Props {
  onGetStarted: () => void;
  onLogin: () => void;
}

export default function Screen01_Splash({ onGetStarted, onLogin }: Screen01Props) {
  return (
    <div 
      className="min-h-screen flex flex-col items-center justify-between px-6 py-12 bg-gradient-to-b from-[#FEEBEC] to-[#FCA3BA]" 
      style={{ height: '852px', width: '393px', margin: '0 auto' }}
    >
      {/* Pricing badge - top right */}
      <div className="absolute top-16 right-6 z-10">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.5, type: 'spring', stiffness: 300 }}
          className="bg-white/95 backdrop-blur-sm rounded-full px-4 py-2 shadow-lg border-2 border-[#C4536C]/20"
        >
          <p className="text-sm text-[#C4536C]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
            Starting at $28
          </p>
        </motion.div>
      </div>

      <div className="h-12" />

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="flex-1 flex flex-col items-center justify-center"
      >
        <img 
          src={logoImage} 
          alt="Nail'd" 
          className="w-72 h-auto mb-12"
          style={{ filter: 'drop-shadow(0 4px 12px rgba(0,0,0,0.1))' }}
        />
        
        <div className="text-center mb-6">
          <h1 className="text-2xl text-[#C4536C] mb-3" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
            For nails as resilient as you
          </h1>
          <p className="text-base text-[#C4536C]/80 mb-4" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 500 }}>
            AI-sized, salon-quality press-ons
          </p>
          <div className="bg-white/80 backdrop-blur-sm rounded-full px-4 py-2 inline-block">
            <p className="text-sm text-[#C4536C]" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
              📦 Get your custom nails in 5-7 days
            </p>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
        className="w-full space-y-4"
      >
        <Button onClick={onGetStarted}>
          Let's Find Your Perfect Fit
        </Button>
        <div className="text-center">
          <TextLink onClick={onLogin}>I already have an account</TextLink>
        </div>
      </motion.div>

      <ScreenLabel label="Welcome" />
    </div>
  );
}
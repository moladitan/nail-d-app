import { motion } from 'motion/react';
import { Lightbulb, Hand } from 'lucide-react';
import Button from '../ui/Button';
import BackButton from '../ui/BackButton';
import StepCounter from '../ui/StepCounter';
import ScreenLabel from '../ui/ScreenLabel';

interface Screen02Props {
  onOpenCamera: () => void;
  onBack: () => void;
}

export default function Screen02_ScanInstructions({ onOpenCamera, onBack }: Screen02Props) {
  const handImageUrl = "https://images.unsplash.com/photo-1599316329891-19df7fa9580d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kJTIwZmxhdCUyMHRhYmxlJTIwcGFsbSUyMGRvd24lMjBtYW5pY3VyZXxlbnwxfHx8fDE3Njk3ODU5NjN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral";

  return (
    <div 
      className="min-h-screen overflow-y-auto bg-gradient-to-b from-[#FCEFE5] to-[#FEEBEC] px-6 py-8" 
      style={{ height: '852px', width: '393px', margin: '0 auto' }}
    >
      <div className="h-4" />
      
      <div className="flex items-center justify-between mb-6">
        <BackButton onClick={onBack} />
        <StepCounter current={0} total={7} />
        <div className="w-10" />
      </div>
      
      <div className="flex flex-col justify-between" style={{ minHeight: 'calc(852px - 200px)' }}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-3xl mb-3 text-[#C4536C] text-center" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
            Let's measure your nails
          </h1>
          <p className="text-base text-[#C4536C]/80 mb-10 text-center leading-relaxed px-4" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 500 }}>
            Take a photo of your hand flat on a table. We'll measure each nail and show you the size.
          </p>

          <div className="w-full aspect-square mb-8 rounded-3xl overflow-hidden shadow-2xl border-4 border-white">
            <img 
              src={handImageUrl} 
              alt="Hand flat on table example" 
              className="w-full h-full object-cover"
            />
          </div>

          <div className="space-y-3">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="flex items-center gap-3 bg-white rounded-2xl p-4 shadow-[0_4px_20px_rgba(196,83,108,0.08)]"
            >
              <div className="w-10 h-10 rounded-xl bg-[#FEEBEC] flex items-center justify-center flex-shrink-0">
                <Lightbulb size={20} className="text-[#E84D7E]" />
              </div>
              <p className="text-[#C4536C] text-sm flex-1" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
                Good lighting (no harsh shadows)
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex items-center gap-3 bg-white rounded-2xl p-4 shadow-[0_4px_20px_rgba(196,83,108,0.08)]"
            >
              <div className="w-10 h-10 rounded-xl bg-[#FEEBEC] flex items-center justify-center flex-shrink-0">
                <Hand size={20} className="text-[#E84D7E]" />
              </div>
              <p className="text-[#C4536C] text-sm flex-1" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
                Hand palm-down, fingers slightly spread
              </p>
            </motion.div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-8"
        >
          <Button onClick={onOpenCamera} variant="primary">
            Open camera
          </Button>
        </motion.div>
      </div>
      
      <ScreenLabel label="Scan Instructions" />
    </div>
  );
}
import { motion } from 'motion/react';
import { Check, Sparkles } from 'lucide-react';
import Button from '../ui/Button';
import ScreenLabel from '../ui/ScreenLabel';

interface Screen14Props {
  design: {
    shape: string;
    colorName: string;
    hasFrenchTip: boolean;
  };
  onTrackOrder: () => void;
  onViewGuide: () => void;
  onShopAgain: () => void;
}

export default function Screen14_OrderConfirmation({ design, onTrackOrder, onViewGuide, onShopAgain }: Screen14Props) {
  // Generate realistic order details
  const orderNumber = '12345';
  const deliveryDate = new Date();
  deliveryDate.setDate(deliveryDate.getDate() + 7);
  const formattedDate = deliveryDate.toLocaleDateString('en-US', { 
    month: 'long', 
    day: 'numeric',
    year: 'numeric'
  });

  return (
    <div 
      className="min-h-screen overflow-y-auto bg-gradient-to-b from-[#FCA3BA] to-[#E84D7E] px-6 py-8 flex flex-col items-center justify-center relative" 
      style={{ height: '852px', width: '393px', margin: '0 auto' }}
    >
      {/* Celebration sparkles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.2, 1, 0.2],
              scale: [0.5, 1.2, 0.5],
            }}
            transition={{
              duration: 2 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          >
            <Sparkles className="text-white/40" size={16 + Math.random() * 12} />
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ 
          duration: 0.6, 
          type: 'spring', 
          stiffness: 200,
          delay: 0.2 
        }}
        className="relative mb-6 z-10"
      >
        <div className="w-32 h-32 rounded-full bg-white flex items-center justify-center shadow-2xl">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.4, delay: 0.5 }}
          >
            <Check size={72} className="text-[#E84D7E]" strokeWidth={3} />
          </motion.div>
        </div>
        
        {[1, 2, 3].map((i) => (
          <motion.div
            key={i}
            className="absolute inset-0 rounded-full border-4 border-white/40"
            initial={{ scale: 1, opacity: 0.8 }}
            animate={{ 
              scale: 1 + i * 0.3, 
              opacity: 0 
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              delay: i * 0.3,
              ease: "easeOut"
            }}
          />
        ))}
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.6 }}
        className="text-4xl mb-3 text-white text-center z-10"
        style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}
      >
        You're Nail'd in! 💅
      </motion.h1>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.7 }}
        className="text-white/90 text-center mb-8 z-10"
        style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 500 }}
      >
        Your order has been confirmed
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.8 }}
        className="w-full bg-white/95 backdrop-blur-lg rounded-3xl p-6 mb-8 shadow-2xl z-10"
      >
        <h3 className="text-lg mb-4 text-[#C4536C]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
          Order details
        </h3>
        
        <div className="mb-4">
          <p className="text-sm text-[#C4536C] mb-1" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 700 }}>
            Custom {design.shape} Set
          </p>
          <p className="text-xs text-[#C4536C]/70" style={{ fontFamily: 'Nunito, sans-serif' }}>
            {design.colorName}{design.hasFrenchTip ? ' with French tip' : ''}
          </p>
        </div>
        
        <div className="border-t border-[#FEEBEC] pt-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#C4536C]/70" style={{ fontFamily: 'Nunito, sans-serif' }}>
              Order number
            </span>
            <span className="text-sm text-[#C4536C]" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 700 }}>
              #{orderNumber}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#C4536C]/70" style={{ fontFamily: 'Nunito, sans-serif' }}>
              Arrives by
            </span>
            <span className="text-sm text-[#C4536C]" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 700 }}>
              {formattedDate}
            </span>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.9 }}
        className="w-full space-y-3 z-10"
      >
        <Button onClick={onTrackOrder} variant="primary" fullWidth>
          Track my order
        </Button>
        <div className="grid grid-cols-2 gap-3">
          <Button onClick={onViewGuide} variant="secondary" fullWidth>
            Care guide
          </Button>
          <Button onClick={onShopAgain} variant="secondary" fullWidth>
            Shop again
          </Button>
        </div>
      </motion.div>
      
      <ScreenLabel label="Order Confirmation" />
    </div>
  );
}

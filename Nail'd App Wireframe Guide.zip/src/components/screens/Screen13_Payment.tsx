import { motion } from 'motion/react';
import { CreditCard, Lock } from 'lucide-react';
import { useState } from 'react';
import Button from '../ui/Button';
import FormInput from '../ui/FormInput';
import BackButton from '../ui/BackButton';
import StepCounter from '../ui/StepCounter';
import ScreenLabel from '../ui/ScreenLabel';

interface Screen13Props {
  total: number;
  design: {
    shape: string;
    colorName: string;
    hasFrenchTip: boolean;
  };
  onPlaceOrder: () => void;
  onBack: () => void;
}

export default function Screen13_Payment({ total, design, onPlaceOrder, onBack }: Screen13Props) {
  // Show filled form example for user testing
  const [paymentData, setPaymentData] = useState({
    cardNumber: '4242 4242 4242 4242',
    expiry: '12/25',
    cvv: '123'
  });

  return (
    <div 
      className="min-h-screen overflow-y-auto bg-[#FCEFE5] px-6 py-8" 
      style={{ height: '852px', width: '393px', margin: '0 auto' }}
    >
      <div className="h-4" />
      
      <div className="flex items-center justify-between mb-6">
        <BackButton onClick={onBack} />
        <StepCounter current={6} total={7} />
        <div className="w-10" />
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-2xl mb-2 text-[#C4536C]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
          Payment
        </h1>
        <p className="text-sm text-[#C4536C]/70 mb-6" style={{ fontFamily: 'Nunito, sans-serif' }}>
          Enter your payment details
        </p>

        <div className="space-y-4 mb-6">
          <FormInput 
            type="text" 
            placeholder="Card number"
            value={paymentData.cardNumber}
            onChange={(e) => setPaymentData({...paymentData, cardNumber: e.target.value})}
          />
          <div className="grid grid-cols-2 gap-4">
            <FormInput 
              type="text" 
              placeholder="MM/YY"
              value={paymentData.expiry}
              onChange={(e) => setPaymentData({...paymentData, expiry: e.target.value})}
            />
            <FormInput 
              type="text" 
              placeholder="CVV"
              value={paymentData.cvv}
              onChange={(e) => setPaymentData({...paymentData, cvv: e.target.value})}
            />
          </div>
        </div>

        <label className="flex items-center gap-2 text-sm text-[#C4536C] mb-6" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
          <input type="checkbox" className="w-5 h-5 rounded accent-[#C4536C]" />
          Save card for next time
        </label>

        <div className="bg-white rounded-3xl p-5 shadow-[0_4px_20px_rgba(196,83,108,0.08)] mb-6">
          <h3 className="text-base mb-3 text-[#C4536C]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
            Order summary
          </h3>
          <div className="space-y-2 mb-3">
            <p className="text-sm text-[#C4536C]" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
              Custom {design.shape} Set
            </p>
            <p className="text-xs text-[#C4536C]/70" style={{ fontFamily: 'Nunito, sans-serif' }}>
              {design.colorName}{design.hasFrenchTip ? ' with French tip' : ''}
            </p>
          </div>
          <div className="border-t border-[#FEEBEC] pt-3 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-[#C4536C]/70" style={{ fontFamily: 'Nunito, sans-serif' }}>Subtotal</span>
              <span className="text-[#C4536C]" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>${total}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-[#C4536C]/70" style={{ fontFamily: 'Nunito, sans-serif' }}>Shipping</span>
              <span className="text-green-600" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>FREE</span>
            </div>
            <div className="border-t border-[#FEEBEC] pt-2 flex justify-between items-center">
              <span className="text-base text-[#C4536C]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>Total</span>
              <span className="text-2xl text-[#E84D7E]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
                ${total}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-[#FFD9A5]/20 rounded-2xl p-3 mb-6 flex items-center gap-2">
          <Lock size={16} className="text-[#E84D7E]" />
          <p className="text-xs text-[#C4536C]" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
            Secure checkout • Your payment info is encrypted
          </p>
        </div>

        <Button onClick={onPlaceOrder} variant="primary">
          Place order • ${total}
        </Button>
      </motion.div>
      
      <ScreenLabel label="Payment" />
    </div>
  );
}

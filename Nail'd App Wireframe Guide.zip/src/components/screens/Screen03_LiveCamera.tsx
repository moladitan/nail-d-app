import { motion } from 'motion/react';
import { Hand, CreditCard, AlertCircle } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import Button from '../ui/Button';
import BackButton from '../ui/BackButton';
import ScreenLabel from '../ui/ScreenLabel';
import { startCamera, stopCamera, capturePhoto, CameraError } from '../../utils/camera';

interface Screen03Props {
  onCapture: (photoData: string) => void;
  onBack: () => void;
}

export default function Screen03_LiveCamera({ onCapture, onBack }: Screen03Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<CameraError | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    const initCamera = async () => {
      try {
        const cameraStream = await startCamera();
        if (!mounted) {
          stopCamera(cameraStream);
          return;
        }

        setStream(cameraStream);
        
        if (videoRef.current) {
          videoRef.current.srcObject = cameraStream;
        }
        
        setIsLoading(false);
      } catch (err) {
        if (mounted) {
          setError(err as CameraError);
          setIsLoading(false);
        }
      }
    };

    initCamera();

    return () => {
      mounted = false;
      if (stream) {
        stopCamera(stream);
      }
    };
  }, []);

  const handleCapture = () => {
    if (videoRef.current && stream) {
      try {
        const photoData = capturePhoto(videoRef.current);
        onCapture(photoData);
      } catch (err) {
        console.error('Failed to capture photo:', err);
      }
    }
  };

  const handleBack = () => {
    if (stream) {
      stopCamera(stream);
    }
    onBack();
  };

  return (
    <div 
      className="min-h-screen overflow-hidden bg-gray-900 relative" 
      style={{ height: '852px', width: '393px', margin: '0 auto' }}
    >
      {/* Video feed or error state */}
      {error ? (
        <div className="absolute inset-0 bg-gray-900 flex items-center justify-center px-8">
          <div className="text-center">
            <AlertCircle size={64} className="text-red-400 mx-auto mb-4" />
            <h2 className="text-xl text-white mb-2" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
              Camera Access Required
            </h2>
            <p className="text-white/80 text-sm mb-6" style={{ fontFamily: 'Nunito, sans-serif' }}>
              {error.message}
            </p>
            <Button onClick={handleBack} variant="primary">
              Go Back
            </Button>
          </div>
        </div>
      ) : (
        <>
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="absolute inset-0 w-full h-full object-cover"
          />

          {isLoading && (
            <div className="absolute inset-0 bg-gray-900 flex items-center justify-center">
              <div className="text-center">
                <div className="w-16 h-16 border-4 border-[#FCA3BA] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                <p className="text-white text-sm" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
                  Starting camera...
                </p>
              </div>
            </div>
          )}
        </>
      )}
      
      <div className="absolute top-0 left-0 right-0 z-30 pt-12 px-6">
        <BackButton onClick={handleBack} />
      </div>
      
      {!error && !isLoading && (
        <>
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="absolute top-0 left-0 right-0 z-20 pt-24 pb-6 bg-gradient-to-b from-black/60 to-transparent"
          >
            <p className="text-white text-center text-sm px-6" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
              Position your hand inside the guide...
            </p>
          </motion.div>

          <div className="absolute inset-0 flex items-center justify-center z-10 px-8">
            <motion.div
              animate={{ 
                scale: [1, 1.02, 1],
                opacity: [0.6, 0.8, 0.6]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="relative"
            >
              <div className="w-72 h-80 rounded-3xl border-4 border-dashed border-white/70 flex items-center justify-center relative">
                <Hand size={160} className="text-white/40" />
                
                <motion.div
                  animate={{ x: [0, -5, 0] }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="absolute -right-12 top-1/2 -translate-y-1/2"
                >
                  <div className="w-20 h-32 rounded-lg border-3 border-dashed border-[#FCA3BA]/80 flex items-center justify-center bg-black/20">
                    <CreditCard size={28} className="text-[#FCA3BA]/60" />
                  </div>
                </motion.div>
              </div>
              
              {['top-0 left-0', 'top-0 right-0', 'bottom-0 left-0', 'bottom-0 right-0'].map((position, i) => (
                <div key={i} className={`absolute ${position} w-8 h-8`}>
                  <div className={`w-full h-1 bg-[#FCA3BA] ${position.includes('bottom') ? 'absolute bottom-0' : ''}`} />
                  <div className={`w-1 h-full bg-[#FCA3BA] ${position.includes('right') ? 'absolute right-0' : ''}`} />
                </div>
              ))}
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="absolute bottom-20 left-0 right-0 px-6 z-20"
          >
            <Button onClick={handleCapture}>
              Capture
            </Button>
          </motion.div>
        </>
      )}
      
      <div className="absolute bottom-4 left-0 right-0 z-20">
        <ScreenLabel label="Camera" />
      </div>
    </div>
  );
}

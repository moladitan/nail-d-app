import { motion } from 'motion/react';
import { Check } from 'lucide-react';
import Button from '../ui/Button';
import StepCounter from '../ui/StepCounter';
import ScreenLabel from '../ui/ScreenLabel';

interface Screen07Props {
  onStartDesigning: () => void;
}

export default function Screen07_NailIDSaved({ onStartDesigning }: Screen07Props) {
  return (
    <div 
      className="min-h-screen overflow-hidden bg-gradient-to-b from-[#FCEFE5] to-[#FEEBEC] px-6 py-8 flex flex-col items-center justify-center" 
      style={{ height: '852px', width: '393px', margin: '0 auto' }}
    >
      <div className="absolute top-12 left-0 right-0 flex justify-center">
        <StepCounter current={4} total={7} />
      </div>

      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ 
          duration: 0.6, 
          type: 'spring', 
          stiffness: 200,
          delay: 0.2 
        }}
        className="relative mb-8"
      >
        <div className="w-32 h-32 rounded-full bg-gradient-to-br from-[#FCA3BA] to-[#E84D7E] flex items-center justify-center shadow-2xl">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.4, delay: 0.5 }}
          >
            <Check size={72} className="text-white" strokeWidth={3} />
          </motion.div>
        </div>
        
        {[1, 2].map((i) => (
          <motion.div
            key={i}
            className="absolute inset-0 rounded-full border-4 border-[#E84D7E]/30"
            initial={{ scale: 1, opacity: 0.6 }}
            animate={{ 
              scale: 1 + i * 0.3, 
              opacity: 0 
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              delay: i * 0.4,
              ease: "easeOut"
            }}
          />
        ))}
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.6 }}
        className="text-3xl mb-4 text-[#C4536C] text-center"
        style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}
      >
        Your nail profile is complete!
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.7 }}
        className="text-[#C4536C]/80 text-base text-center mb-12 leading-relaxed px-8"
        style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 500 }}
      >
        We'll use this to make every set fit you perfectly. You can rescan anytime.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.8 }}
        className="w-full"
      >
        <Button onClick={onStartDesigning} variant="primary">
          Start designing
        </Button>
      </motion.div>
      
      <div className="absolute bottom-4 left-0 right-0">
        <ScreenLabel label="Nail ID Saved" />
      </div>
    </div>
  );
}
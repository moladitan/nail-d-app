import { motion } from 'motion/react';
import Button from '../ui/Button';
import TextLink from '../ui/TextLink';
import BackButton from '../ui/BackButton';
import StepCounter from '../ui/StepCounter';
import ScreenLabel from '../ui/ScreenLabel';

interface Screen06Props {
  nailSizes: any;
  onSave: () => void;
  onRescan: () => void;
  onBack: () => void;
}

export default function Screen06_SizeResults({ nailSizes, onSave, onRescan, onBack }: Screen06Props) {
  const leftHand = nailSizes?.leftHand || {
    thumb: 'S',
    index: 'M',
    middle: 'M',
    ring: 'M',
    pinky: 'S'
  };

  const rightHand = nailSizes?.rightHand || {
    thumb: 'S',
    index: 'M',
    middle: 'M',
    ring: 'M',
    pinky: 'S'
  };

  const fingers = [
    { name: 'Thumb', leftSize: leftHand.thumb, rightSize: rightHand.thumb },
    { name: 'Index', leftSize: leftHand.index, rightSize: rightHand.index },
    { name: 'Middle', leftSize: leftHand.middle, rightSize: rightHand.middle },
    { name: 'Ring', leftSize: leftHand.ring, rightSize: rightHand.ring },
    { name: 'Pinky', leftSize: leftHand.pinky, rightSize: rightHand.pinky }
  ];

  return (
    <div 
      className="min-h-screen overflow-y-auto bg-gradient-to-b from-[#FCEFE5] to-[#FEEBEC] px-6 py-8" 
      style={{ height: '852px', width: '393px', margin: '0 auto' }}
    >
      <div className="h-4" />
      
      <div className="flex items-center justify-between mb-8">
        <BackButton onClick={onBack} />
        <StepCounter current={3} total={7} />
        <div className="w-10" />
      </div>
      
      <div className="flex flex-col items-center">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-2xl mb-2 text-[#C4536C] text-center"
          style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}
        >
          Here's your nail size profile
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-sm text-[#C4536C]/70 mb-8 text-center px-4"
          style={{ fontFamily: 'Nunito, sans-serif' }}
        >
          These are your custom nail sizes. Every set you design will be made to fit perfectly.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="w-full bg-white rounded-3xl p-8 shadow-[0_8px_40px_rgba(196,83,108,0.12)] mb-6"
        >
          <div className="mb-8">
            <h3 className="text-xs text-[#C4536C]/60 mb-4 text-center" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 700 }}>
              LEFT HAND
            </h3>
            <div className="flex justify-center gap-3">
              {fingers.map((finger, index) => (
                <motion.div 
                  key={`left-${index}`} 
                  className="flex flex-col items-center gap-2"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: 0.3 + index * 0.1 }}
                >
                  <div className="w-12 h-20 rounded-t-full bg-gradient-to-b from-[#FCA3BA]/40 to-[#FCA3BA]/10 border-3 border-[#FCA3BA] flex items-end justify-center pb-2 shadow-lg">
                    <span className="text-base text-[#E84D7E]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
                      {finger.leftSize}
                    </span>
                  </div>
                  <span className="text-[10px] text-[#C4536C]/60" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
                    {finger.name}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-xs text-[#C4536C]/60 mb-4 text-center" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 700 }}>
              RIGHT HAND
            </h3>
            <div className="flex justify-center gap-3">
              {fingers.map((finger, index) => (
                <motion.div 
                  key={`right-${index}`} 
                  className="flex flex-col items-center gap-2"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: 0.8 + index * 0.1 }}
                >
                  <div className="w-12 h-20 rounded-t-full bg-gradient-to-b from-[#FCA3BA]/40 to-[#FCA3BA]/10 border-3 border-[#FCA3BA] flex items-end justify-center pb-2 shadow-lg">
                    <span className="text-base text-[#E84D7E]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
                      {finger.rightSize}
                    </span>
                  </div>
                  <span className="text-[10px] text-[#C4536C]/60" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
                    {finger.name}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.3 }}
          className="w-full space-y-3"
        >
          <Button onClick={onSave} variant="primary">
            Save my sizes
          </Button>
          <div className="text-center">
            <TextLink onClick={onRescan}>Rescan if needed</TextLink>
          </div>
        </motion.div>
      </div>
      
      <ScreenLabel label="Size Results" />
    </div>
  );
}

import { motion } from 'motion/react';
import { Hand, ZoomIn, Loader2 } from 'lucide-react';
import { useState, useEffect } from 'react';
import Button from '../ui/Button';
import BackButton from '../ui/BackButton';
import StepCounter from '../ui/StepCounter';
import ScreenLabel from '../ui/ScreenLabel';
import { analyzeMockNailSizes } from '../../utils/camera';

interface Screen05Props {
  capturedPhoto: string | null;
  onConfirm: (nailSizes: any) => void;
  onBack: () => void;
}

export default function Screen05_AdjustOutlines({ capturedPhoto, onConfirm, onBack }: Screen05Props) {
  const [isProcessing, setIsProcessing] = useState(true);
  const [nailSizes, setNailSizes] = useState<any>(null);

  useEffect(() => {
    const analyzeImage = async () => {
      if (capturedPhoto) {
        try {
          const sizes = await analyzeMockNailSizes(capturedPhoto);
          setNailSizes(sizes);
          setIsProcessing(false);
        } catch (error) {
          console.error('Analysis failed:', error);
          setIsProcessing(false);
        }
      }
    };

    analyzeImage();
  }, [capturedPhoto]);

  const handleConfirm = () => {
    onConfirm(nailSizes);
  };

  return (
    <div 
      className="min-h-screen overflow-y-auto bg-[#FCEFE5] px-6 py-8" 
      style={{ height: '852px', width: '393px', margin: '0 auto' }}
    >
      <div className="h-4" />
      
      <div className="flex items-center justify-between mb-6">
        <BackButton onClick={onBack} />
        <StepCounter current={2} total={7} />
        <div className="w-10" />
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-2xl mb-2 text-[#C4536C]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
          {isProcessing ? 'Analyzing your nails...' : 'Adjust your nail outlines'}
        </h1>
        <p className="text-sm text-[#C4536C]/80 mb-6 leading-relaxed" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 500 }}>
          {isProcessing ? 'Our AI is detecting your nail boundaries' : 'We detected your nails. You can adjust the outline if needed.'}
        </p>

        {isProcessing ? (
          <div className="relative mb-6 rounded-3xl overflow-hidden shadow-2xl bg-white border-4 border-white">
            <div className="w-full aspect-square bg-gradient-to-br from-[#FEEBEC] to-[#FCA3BA]/20 relative flex items-center justify-center">
              {capturedPhoto && (
                <img 
                  src={capturedPhoto} 
                  alt="Analyzing" 
                  className="absolute inset-0 w-full h-full object-cover opacity-40"
                />
              )}
              <div className="relative z-10 text-center">
                <Loader2 size={48} className="text-[#E84D7E] animate-spin mx-auto mb-4" />
                <p className="text-[#C4536C] text-sm" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
                  Analyzing your nails...
                </p>
                <div className="mt-4 flex items-center justify-center gap-2">
                  <div className="w-2 h-2 bg-[#E84D7E] rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 bg-[#E84D7E] rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 bg-[#E84D7E] rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="relative mb-6 rounded-3xl overflow-hidden shadow-2xl bg-white border-4 border-white">
            <div className="w-full aspect-square bg-gradient-to-br from-[#FEEBEC] to-[#FCA3BA]/20 relative">
              {capturedPhoto && (
                <img 
                  src={capturedPhoto} 
                  alt="Hand with detected nails" 
                  className="absolute inset-0 w-full h-full object-cover opacity-60"
                />
              )}
              
              {[
                { finger: 'Thumb', position: 'left-16 top-32', color: '#E84D7E' },
                { finger: 'Index', position: 'left-32 top-16', color: '#FCA3BA' },
                { finger: 'Middle', position: 'left-1/2 -translate-x-1/2 top-8', color: '#C4536C' },
                { finger: 'Ring', position: 'right-32 top-16', color: '#FCA3BA' },
                { finger: 'Pinky', position: 'right-16 top-28', color: '#FFD9A5' }
              ].map((nail, index) => (
                <motion.div
                  key={nail.finger}
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.4, delay: 0.1 * index }}
                  className={`absolute ${nail.position}`}
                >
                  <div 
                    className="w-8 h-12 rounded-t-full border-3 cursor-pointer hover:scale-110 transition-transform"
                    style={{ borderColor: nail.color, borderWidth: '3px' }}
                  />
                  <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 whitespace-nowrap">
                    <span 
                      className="text-xs px-2 py-1 rounded-full"
                      style={{ 
                        backgroundColor: nail.color, 
                        color: 'white',
                        fontFamily: 'Nunito, sans-serif',
                        fontWeight: 700
                      }}
                    >
                      {nail.finger}
                    </span>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="absolute bottom-4 right-4 bg-black/60 text-white px-3 py-2 rounded-full flex items-center gap-2">
              <ZoomIn size={16} />
              <span className="text-xs" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
                Pinch to zoom
              </span>
            </div>
          </div>
        )}

        {!isProcessing && (
          <>
            <div className="bg-[#FFD9A5]/20 rounded-2xl p-4 mb-8">
              <p className="text-sm text-[#C4536C] text-center" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 500 }}>
                💡 Tap and drag any outline to adjust
              </p>
            </div>

            <Button onClick={handleConfirm} variant="primary">
              Looks good
            </Button>
          </>
        )}
      </motion.div>
      
      <ScreenLabel label="AI Processing & Outline Adjustment" />
    </div>
  );
}

import { motion } from 'motion/react';
import { useState } from 'react';
import Button from '../ui/Button';
import ColorSwatch from '../ui/ColorSwatch';
import BackButton from '../ui/BackButton';
import StepCounter from '../ui/StepCounter';
import ScreenLabel from '../ui/ScreenLabel';
import HandPreview from '../ui/HandPreview';

interface Screen09Props {
  shape: string;
  onNext: (color: string, colorName: string) => void;
  onBack: () => void;
}

export default function Screen09_ChooseColor({ shape, onNext, onBack }: Screen09Props) {
  const [selectedColor, setSelectedColor] = useState('#C4536C');
  const [selectedColorName, setSelectedColorName] = useState('Deep Rose');
  
  const handImageUrl = "https://images.unsplash.com/photo-1741886419563-681e5da31b2c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMGhhbmQlMjBuYWlscyUyMG1hbmljdXJlJTIwdG9wJTIwdmlld3xlbnwxfHx8fDE3Njk3ODU5NjN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral";

  const colors = [
    { color: '#C4536C', label: 'Deep Rose' },
    { color: '#FFD9A5', label: 'Nude' },
    { color: '#2D2D2D', label: 'Black' }
  ];

  const handleColorSelect = (color: string, label: string) => {
    setSelectedColor(color);
    setSelectedColorName(label);
  };

  return (
    <div 
      className="min-h-screen overflow-y-auto bg-[#FCEFE5] px-6 py-8" 
      style={{ height: '852px', width: '393px', margin: '0 auto' }}
    >
      <div className="h-4" />
      
      <div className="flex items-center justify-between mb-6">
        <BackButton onClick={onBack} />
        <StepCounter current={5} total={7} />
        <div className="w-10" />
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-2xl mb-1 text-[#C4536C]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
          Nail Studio
        </h1>
        <p className="text-base text-[#C4536C]/70 mb-6" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 500 }}>
          Choose your color
        </p>

        <div className="mb-6">
          <HandPreview 
            color={selectedColor}
            shape={shape}
            hasFrenchTip={false}
            imageUrl={handImageUrl}
          />
        </div>

        <h2 className="text-sm text-[#C4536C] mb-4" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 700, letterSpacing: '0.5px' }}>
          SELECT COLOR
        </h2>

        <div className="flex justify-around mb-12">
          {colors.map((c) => (
            <ColorSwatch
              key={c.color}
              color={c.color}
              label={c.label}
              selected={selectedColor === c.color}
              onClick={() => handleColorSelect(c.color, c.label)}
            />
          ))}
        </div>

        <div 
          className="rounded-3xl p-12 mb-8 flex items-center justify-center shadow-lg transition-all duration-300"
          style={{ backgroundColor: selectedColor }}
        >
          <motion.div
            key={selectedColor}
            initial={{ scale: 0.8, rotate: -10 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ duration: 0.4, type: 'spring' }}
            className="text-9xl filter drop-shadow-2xl"
          >
            💅
          </motion.div>
        </div>

        <Button onClick={() => onNext(selectedColor, selectedColorName)} variant="primary">
          Next
        </Button>
      </motion.div>
      
      <ScreenLabel label="Nail Studio - Choose Color" />
    </div>
  );
}
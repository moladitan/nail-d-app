import { motion } from 'motion/react';
import { Package } from 'lucide-react';
import { useState } from 'react';
import Button from '../ui/Button';
import FormInput from '../ui/FormInput';
import BackButton from '../ui/BackButton';
import StepCounter from '../ui/StepCounter';
import ScreenLabel from '../ui/ScreenLabel';
import TextLink from '../ui/TextLink';

interface Screen12Props {
  onContinuePayment: () => void;
  onBack: () => void;
}

export default function Screen12_ShippingInfo({ onContinuePayment, onBack }: Screen12Props) {
  // Show filled form example for user testing
  const [formData, setFormData] = useState({
    fullName: 'Sarah Johnson',
    address: '123 Main Street, Apt 4B',
    city: 'San Francisco',
    state: 'CA',
    zip: '94102',
    phone: '(555) 123-4567'
  });

  return (
    <div 
      className="min-h-screen overflow-y-auto bg-[#FCEFE5] px-6 py-8" 
      style={{ height: '852px', width: '393px', margin: '0 auto' }}
    >
      <div className="h-4" />
      
      <div className="flex items-center justify-between mb-6">
        <BackButton onClick={onBack} />
        <StepCounter current={6} total={7} />
        <div className="w-10" />
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-2xl mb-2 text-[#C4536C]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
          Shipping info
        </h1>
        <p className="text-sm text-[#C4536C]/70 mb-6" style={{ fontFamily: 'Nunito, sans-serif' }}>
          Where should we send your custom nails?
        </p>

        <div className="space-y-4 mb-6">
          <FormInput 
            type="text" 
            placeholder="Full name"
            value={formData.fullName}
            onChange={(e) => setFormData({...formData, fullName: e.target.value})}
          />
          <FormInput 
            type="text" 
            placeholder="Address"
            value={formData.address}
            onChange={(e) => setFormData({...formData, address: e.target.value})}
          />
          <div className="grid grid-cols-2 gap-4">
            <FormInput 
              type="text" 
              placeholder="City"
              value={formData.city}
              onChange={(e) => setFormData({...formData, city: e.target.value})}
            />
            <FormInput 
              type="text" 
              placeholder="State"
              value={formData.state}
              onChange={(e) => setFormData({...formData, state: e.target.value})}
            />
          </div>
          <FormInput 
            type="text" 
            placeholder="ZIP code"
            value={formData.zip}
            onChange={(e) => setFormData({...formData, zip: e.target.value})}
          />
          <FormInput 
            type="tel" 
            placeholder="Phone number"
            value={formData.phone}
            onChange={(e) => setFormData({...formData, phone: e.target.value})}
          />
        </div>

        <label className="flex items-center gap-2 text-sm text-[#C4536C] mb-6" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
          <input type="checkbox" defaultChecked className="w-5 h-5 rounded accent-[#C4536C]" />
          Save for next time
        </label>

        <div className="bg-[#FFD9A5]/20 rounded-2xl p-4 mb-6 flex items-center gap-3">
          <Package size={24} className="text-[#E84D7E] flex-shrink-0" />
          <div>
            <p className="text-sm text-[#C4536C]" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 700 }}>
              Estimated delivery: 5-7 business days
            </p>
            <p className="text-xs text-[#C4536C]/70" style={{ fontFamily: 'Nunito, sans-serif' }}>
              📦 Free shipping on all orders
            </p>
          </div>
        </div>

        <div className="text-center mb-6">
          <TextLink onClick={() => {}}>Need help with shipping?</TextLink>
        </div>

        <Button onClick={onContinuePayment} variant="primary">
          Continue to payment
        </Button>
      </motion.div>
      
      <ScreenLabel label="Shipping Information" />
    </div>
  );
}

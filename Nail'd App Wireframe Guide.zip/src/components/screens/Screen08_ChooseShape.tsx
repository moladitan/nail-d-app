import { motion } from 'motion/react';
import { useState } from 'react';
import Button from '../ui/Button';
import ShapeCard from '../ui/ShapeCard';
import BackButton from '../ui/BackButton';
import StepCounter from '../ui/StepCounter';
import ScreenLabel from '../ui/ScreenLabel';
import HandPreview from '../ui/HandPreview';

interface Screen08Props {
  onNext: (shape: string) => void;
  onBack: () => void;
}

export default function Screen08_ChooseShape({ onNext, onBack }: Screen08Props) {
  const [selectedShape, setSelectedShape] = useState('Almond');
  
  const handImageUrl = "https://images.unsplash.com/photo-1741886419563-681e5da31b2c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMGhhYW5kJTIwbmFpbHN5JTIwbWFuaWN1cmUJTIwdG9wJTIwdmlld3xlbnwxfHx8fDE3Njk3ODU5NjN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral";

  const shapes = [
    { icon: '💅', label: 'Almond' },
    { icon: '💎', label: 'Coffin' },
    { icon: '⬜', label: 'Square' },
    { icon: '⭕', label: 'Oval' }
  ];

  return (
    <div 
      className="min-h-screen overflow-y-auto bg-[#FCEFE5] px-6 py-8" 
      style={{ height: '852px', width: '393px', margin: '0 auto' }}
    >
      <div className="h-4" />
      
      <div className="flex items-center justify-between mb-6">
        <BackButton onClick={onBack} />
        <StepCounter current={5} total={7} />
        <div className="w-10" />
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-2xl mb-1 text-[#C4536C]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
          Nail Studio
        </h1>
        <p className="text-base text-[#C4536C]/70 mb-6" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 500 }}>
          Choose your nail shape
        </p>

        <div className="mb-6">
          <HandPreview 
            color="#FCA3BA"
            shape={selectedShape}
            hasFrenchTip={false}
            imageUrl={handImageUrl}
          />
        </div>

        <h2 className="text-sm text-[#C4536C] mb-4" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 700, letterSpacing: '0.5px' }}>
          SELECT SHAPE
        </h2>

        <div className="grid grid-cols-2 gap-3 mb-8">
          {shapes.map((shape) => (
            <ShapeCard
              key={shape.label}
              icon={shape.icon}
              label={shape.label}
              selected={selectedShape === shape.label}
              onClick={() => setSelectedShape(shape.label)}
            />
          ))}
        </div>

        <div className="bg-gradient-to-br from-[#FEEBEC] to-[#FCA3BA]/20 rounded-3xl p-8 mb-8 flex items-center justify-center">
          <motion.div
            key={selectedShape}
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="text-8xl"
          >
            💅
          </motion.div>
        </div>

        <Button onClick={() => onNext(selectedShape)} variant="primary">
          Next
        </Button>
      </motion.div>
      
      <ScreenLabel label="Nail Studio - Choose Shape" />
    </div>
  );
}
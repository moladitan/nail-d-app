import { motion } from 'motion/react';
import Button from '../ui/Button';
import BackButton from '../ui/BackButton';
import StepCounter from '../ui/StepCounter';
import ScreenLabel from '../ui/ScreenLabel';

interface Screen04Props {
  capturedPhoto: string | null;
  onRetake: () => void;
  onAnalyze: () => void;
  onBack: () => void;
}

export default function Screen04_PhotoReview({ capturedPhoto, onRetake, onAnalyze, onBack }: Screen04Props) {
  return (
    <div 
      className="min-h-screen overflow-hidden bg-[#FCEFE5] flex flex-col" 
      style={{ height: '852px', width: '393px', margin: '0 auto' }}
    >
      <div className="h-4" />
      
      <div className="flex items-center justify-between px-6 mb-4">
        <BackButton onClick={onBack} />
        <StepCounter current={1} total={7} />
        <div className="w-10" />
      </div>
      
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="flex-1 flex items-center justify-center px-6 py-8"
      >
        <div className="w-full aspect-square rounded-3xl shadow-2xl overflow-hidden relative border-4 border-white">
          {capturedPhoto ? (
            <img 
              src={capturedPhoto} 
              alt="Captured hand" 
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-[#FEEBEC] to-[#FCA3BA]/20 flex items-center justify-center">
              <p className="text-[#C4536C] text-sm" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
                No photo captured
              </p>
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent" />
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
        className="px-6 pb-4"
      >
        <div className="flex gap-3">
          <Button onClick={onRetake} variant="secondary">
            Retake
          </Button>
          <Button onClick={onAnalyze} variant="primary">
            Analyze
          </Button>
        </div>
      </motion.div>
      
      <ScreenLabel label="Photo Review" />
    </div>
  );
}

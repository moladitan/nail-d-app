import { motion } from 'motion/react';
import { Minus, Plus } from 'lucide-react';
import { useState } from 'react';
import Button from '../ui/Button';
import BackButton from '../ui/BackButton';
import StepCounter from '../ui/StepCounter';
import ScreenLabel from '../ui/ScreenLabel';

interface Screen11Props {
  shape: string;
  color: string;
  colorName: string;
  hasFrenchTip: boolean;
  onProceedCheckout: () => void;
  onBack: () => void;
}

export default function Screen11_Cart({ shape, color, colorName, hasFrenchTip, onProceedCheckout, onBack }: Screen11Props) {
  const [quantity, setQuantity] = useState(1);
  const [promoCode, setPromoCode] = useState('');
  const [promoError, setPromoError] = useState('');
  const [promoApplied, setPromoApplied] = useState(false);

  const pricePerSet = 28;
  const subtotal = pricePerSet * quantity;
  const shipping = 0; // Free shipping
  const discount = promoApplied ? 5 : 0;
  const total = subtotal + shipping - discount;

  const handleApplyPromo = () => {
    if (promoCode.toUpperCase() === 'WELCOME10') {
      setPromoApplied(true);
      setPromoError('');
    } else if (promoCode) {
      setPromoError('Invalid promo code');
      setPromoApplied(false);
    }
  };

  return (
    <div 
      className="min-h-screen overflow-y-auto bg-[#FCEFE5] px-6 py-8" 
      style={{ height: '852px', width: '393px', margin: '0 auto' }}
    >
      <div className="h-4" />
      
      <div className="flex items-center justify-between mb-6">
        <BackButton onClick={onBack} />
        <StepCounter current={6} total={7} />
        <div className="w-10" />
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-2xl mb-8 text-[#C4536C]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
          Your custom set
        </h1>

        <div className="bg-white rounded-3xl p-5 shadow-[0_4px_20px_rgba(196,83,108,0.08)] mb-6">
          <div className="flex gap-4 mb-4">
            <div 
              className="w-24 h-24 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg relative overflow-hidden"
              style={{ backgroundColor: color }}
            >
              <span className="text-4xl filter drop-shadow-lg">💅</span>
              {hasFrenchTip && (
                <div className="absolute top-0 left-0 right-0 h-6 bg-white/40 blur-sm" />
              )}
            </div>
            
            <div className="flex-1">
              <h3 className="text-base mb-1 text-[#C4536C]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
                Custom {shape} Set
              </h3>
              <p className="text-sm text-[#C4536C]/70 mb-2" style={{ fontFamily: 'Nunito, sans-serif' }}>
                {colorName}{hasFrenchTip ? ' with French tip' : ''}
              </p>
              <div className="inline-flex items-center gap-1 bg-[#FFD9A5]/30 px-2 py-1 rounded-full">
                <span className="text-xs text-[#C4536C]" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 700 }}>
                  ✓ Your Nail ID
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-[#FEEBEC]">
            <span className="text-xl text-[#E84D7E]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
              ${pricePerSet}
            </span>
            
            <div className="flex items-center gap-2 bg-[#FEEBEC] rounded-xl px-2">
              <button 
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="p-2 text-[#C4536C]"
              >
                <Minus size={16} />
              </button>
              <span className="text-base w-8 text-center text-[#C4536C]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 600 }}>
                {quantity}
              </span>
              <button 
                onClick={() => setQuantity(quantity + 1)}
                className="p-2 text-[#C4536C]"
              >
                <Plus size={16} />
              </button>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <div className="flex gap-2">
            <input
              type="text"
              value={promoCode}
              onChange={(e) => {
                setPromoCode(e.target.value);
                setPromoError('');
              }}
              placeholder="Promo code (try WELCOME10)"
              className={`flex-1 h-14 px-4 rounded-xl border-2 bg-white outline-none transition-colors ${
                promoError ? 'border-red-400' : promoApplied ? 'border-green-400' : 'border-[#F0E0E8] focus:border-[#FCA3BA]'
              }`}
              style={{ fontFamily: 'Nunito, sans-serif', fontSize: '14px' }}
            />
            <button
              onClick={handleApplyPromo}
              className="px-6 h-14 bg-[#C4536C] text-white rounded-xl"
              style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}
            >
              Apply
            </button>
          </div>
          {promoError && (
            <p className="text-xs text-red-500 mt-2" style={{ fontFamily: 'Nunito, sans-serif' }}>
              {promoError}
            </p>
          )}
          {promoApplied && (
            <p className="text-xs text-green-600 mt-2" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
              ✓ Promo code applied! $5 off
            </p>
          )}
        </div>

        <div className="bg-white rounded-3xl p-5 shadow-[0_4px_20px_rgba(196,83,108,0.08)] mb-8">
          <h3 className="text-base mb-4 text-[#C4536C]" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
            Order summary
          </h3>
          <div className="space-y-3 text-sm" style={{ fontFamily: 'Nunito, sans-serif' }}>
            <div className="flex justify-between text-[#C4536C]/80">
              <span>Subtotal</span>
              <span>${subtotal}</span>
            </div>
            <div className="flex justify-between text-[#C4536C]/80">
              <span>Shipping</span>
              <span className="text-green-600 font-semibold">FREE</span>
            </div>
            {promoApplied && (
              <div className="flex justify-between text-green-600">
                <span>Discount</span>
                <span>-${discount}</span>
              </div>
            )}
            <div className="border-t border-[#FEEBEC] pt-3 flex justify-between text-lg text-[#E84D7E]" style={{ fontWeight: 700 }}>
              <span>Total</span>
              <span>${total}</span>
            </div>
          </div>
        </div>

        <Button onClick={onProceedCheckout} variant="primary">
          Proceed to checkout
        </Button>
      </motion.div>
      
      <ScreenLabel label="Cart" />
    </div>
  );
}

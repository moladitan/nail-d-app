import { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, ScanLine } from 'lucide-react';

interface WelcomeScanProps {
  onNext: () => void;
}

export default function WelcomeScan({ onNext }: WelcomeScanProps) {
  const [isScanning, setIsScanning] = useState(false);

  const handleScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      onNext();
    }, 2500);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-[#FEEBEC] to-[#FCEFE5]">
      {/* Header with logo */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="flex items-center justify-center gap-2 px-6 py-6 bg-white/70 backdrop-blur-xl border-b border-[#FCA3BA]/30 shadow-sm"
      >
        <span className="text-2xl tracking-tight" style={{ fontFamily: 'Poppins, sans-serif', color: '#C4536C', fontWeight: 700 }}>Nail'd</span>
        <motion.div
          animate={{
            rotate: [0, 15, -15, 0],
            scale: [1, 1.3, 1],
          }}
          transition={{
            duration: 2.5,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <Sparkles className="text-[#FFD9A5] drop-shadow-md" size={24} />
        </motion.div>
      </motion.div>

      {/* Title Section */}
      <div className="px-6 py-8 text-center">
        <motion.h2
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="text-3xl text-[#C4536C] mb-3"
          style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}
        >
          Let's Scan Your Nails
        </motion.h2>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="text-[#A05C6E] text-base"
          style={{ fontFamily: 'Nunito, sans-serif' }}
        >
          Place your hand flat within the frame
        </motion.p>
      </div>

      {/* Main Scan Area */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          className="relative w-full max-w-md"
        >
          {/* Scan Frame */}
          <div className="relative aspect-[3/4] bg-gradient-to-br from-white/50 to-white/30 backdrop-blur-sm rounded-3xl border-3 border-dashed border-[#FCA3BA]/60 shadow-[0_8px_32px_rgba(196,83,108,0.12)] overflow-hidden">
            
            {/* Corner markers */}
            <div className="absolute top-4 left-4 w-6 h-6 border-t-4 border-l-4 border-[#E84D7E] rounded-tl-lg" />
            <div className="absolute top-4 right-4 w-6 h-6 border-t-4 border-r-4 border-[#E84D7E] rounded-tr-lg" />
            <div className="absolute bottom-4 left-4 w-6 h-6 border-b-4 border-l-4 border-[#E84D7E] rounded-bl-lg" />
            <div className="absolute bottom-4 right-4 w-6 h-6 border-b-4 border-r-4 border-[#E84D7E] rounded-br-lg" />

            {/* Realistic Hand with Nails SVG */}
            <svg 
              width="100%" 
              height="100%" 
              viewBox="0 0 280 400" 
              className="absolute inset-0"
              preserveAspectRatio="xMidYMid meet"
            >
              <defs>
                {/* Gradient for hand skin tone */}
                <linearGradient id="skinGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#FFE4E1" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#FFD7D3" stopOpacity="0.8" />
                </linearGradient>
                {/* Gradient for nails */}
                <linearGradient id="nailGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#FFF5F5" stopOpacity="0.95" />
                  <stop offset="100%" stopColor="#FFE8E8" stopOpacity="0.95" />
                </linearGradient>
              </defs>

              {/* Palm - more realistic shape */}
              <path
                d="M 100 280 Q 85 260, 80 230 L 80 200 Q 78 180, 90 165 L 100 150 Q 110 165, 120 150 L 130 165 Q 140 150, 150 165 L 160 150 Q 165 160, 180 165 L 185 180 Q 190 200, 188 230 L 185 270 Q 180 290, 165 305 Q 150 315, 140 315 Q 120 315, 100 280 Z"
                fill="url(#skinGradient)"
                stroke="#C4536C"
                strokeWidth="2"
                opacity="0.9"
              />

              {/* Thumb */}
              <ellipse cx="65" cy="220" rx="18" ry="45" fill="url(#skinGradient)" stroke="#C4536C" strokeWidth="2" opacity="0.9" transform="rotate(-25 65 220)" />
              <ellipse cx="58" cy="195" rx="8" ry="12" fill="url(#nailGradient)" stroke="#E84D7E" strokeWidth="1.5" transform="rotate(-25 58 195)" />

              {/* Index Finger */}
              <g>
                <rect x="90" y="60" width="22" height="95" rx="11" fill="url(#skinGradient)" stroke="#C4536C" strokeWidth="2" opacity="0.9" />
                {/* Index fingertip */}
                <ellipse cx="101" cy="63" rx="11" ry="8" fill="url(#skinGradient)" stroke="#C4536C" strokeWidth="2" opacity="0.9" />
                {/* Index nail - realistic oval shape */}
                <ellipse cx="101" cy="70" rx="9" ry="14" fill="url(#nailGradient)" stroke="#E84D7E" strokeWidth="1.5" />
                <ellipse cx="101" cy="68" rx="6" ry="10" fill="#FFF" opacity="0.3" />
              </g>

              {/* Middle Finger */}
              <g>
                <rect x="120" y="40" width="24" height="115" rx="12" fill="url(#skinGradient)" stroke="#C4536C" strokeWidth="2" opacity="0.9" />
                {/* Middle fingertip */}
                <ellipse cx="132" cy="43" rx="12" ry="8" fill="url(#skinGradient)" stroke="#C4536C" strokeWidth="2" opacity="0.9" />
                {/* Middle nail */}
                <ellipse cx="132" cy="52" rx="10" ry="16" fill="url(#nailGradient)" stroke="#E84D7E" strokeWidth="1.5" />
                <ellipse cx="132" cy="50" rx="7" ry="11" fill="#FFF" opacity="0.3" />
              </g>

              {/* Ring Finger */}
              <g>
                <rect x="152" y="60" width="22" height="95" rx="11" fill="url(#skinGradient)" stroke="#C4536C" strokeWidth="2" opacity="0.9" />
                {/* Ring fingertip */}
                <ellipse cx="163" cy="63" rx="11" ry="8" fill="url(#skinGradient)" stroke="#C4536C" strokeWidth="2" opacity="0.9" />
                {/* Ring nail */}
                <ellipse cx="163" cy="70" rx="9" ry="14" fill="url(#nailGradient)" stroke="#E84D7E" strokeWidth="1.5" />
                <ellipse cx="163" cy="68" rx="6" ry="10" fill="#FFF" opacity="0.3" />
              </g>

              {/* Pinky Finger */}
              <g>
                <rect x="180" y="85" width="19" height="80" rx="9.5" fill="url(#skinGradient)" stroke="#C4536C" strokeWidth="2" opacity="0.9" />
                {/* Pinky fingertip */}
                <ellipse cx="189.5" cy="88" rx="9.5" ry="7" fill="url(#skinGradient)" stroke="#C4536C" strokeWidth="2" opacity="0.9" />
                {/* Pinky nail */}
                <ellipse cx="189.5" cy="94" rx="7.5" ry="12" fill="url(#nailGradient)" stroke="#E84D7E" strokeWidth="1.5" />
                <ellipse cx="189.5" cy="92" rx="5" ry="8" fill="#FFF" opacity="0.3" />
              </g>
            </svg>

            {/* Scanning animation overlay */}
            {isScanning && (
              <>
                {/* Horizontal scan line */}
                <motion.div
                  className="absolute left-0 right-0 h-1 flex items-center justify-center"
                  animate={{
                    top: ['0%', '100%'],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "linear"
                  }}
                >
                  <div className="w-full h-full bg-gradient-to-r from-transparent via-[#E84D7E] to-transparent opacity-80 shadow-[0_0_20px_rgba(232,77,126,0.8)]" />
                  <ScanLine className="absolute text-[#E84D7E] animate-pulse" size={28} />
                </motion.div>

                {/* Scanning grid overlay */}
                <motion.div
                  className="absolute inset-0"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0.3, 0.6, 0.3] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                >
                  <div className="w-full h-full" style={{
                    backgroundImage: `
                      linear-gradient(to right, rgba(252, 163, 186, 0.15) 1px, transparent 1px),
                      linear-gradient(to bottom, rgba(252, 163, 186, 0.15) 1px, transparent 1px)
                    `,
                    backgroundSize: '20px 20px'
                  }} />
                </motion.div>

                {/* Sparkle particles */}
                {[...Array(6)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute"
                    style={{
                      left: `${20 + Math.random() * 60}%`,
                      top: `${20 + Math.random() * 60}%`,
                    }}
                    animate={{
                      opacity: [0, 1, 0],
                      scale: [0.5, 1.2, 0.5],
                      y: [0, -20, 0],
                    }}
                    transition={{
                      duration: 1.5,
                      repeat: Infinity,
                      delay: i * 0.25,
                    }}
                  >
                    <Sparkles className="text-[#FFD9A5]" size={20} />
                  </motion.div>
                ))}

                {/* Scanning progress text */}
                <motion.div
                  className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-[#E84D7E] text-white px-4 py-2 rounded-full text-sm shadow-lg"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  Analyzing nail dimensions...
                </motion.div>
              </>
            )}
          </div>

          {/* Instructions */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mt-6 text-center"
          >
            <p className="text-[#A05C6E] mb-2">
              {isScanning ? 'Hold steady...' : 'Position your hand in the center'}
            </p>
            <div className="flex items-center justify-center gap-2 text-sm text-[#C4536C]/70">
              <div className="w-2 h-2 rounded-full bg-[#E84D7E]" />
              <span>Ensure good lighting</span>
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Bottom CTA Section */}
      <div className="px-6 pb-8 pt-4">
        <div className="w-full max-w-md mx-auto space-y-3">
          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            whileHover={{ scale: isScanning ? 1 : 1.02 }}
            whileTap={{ scale: isScanning ? 1 : 0.98 }}
            onClick={handleScan}
            disabled={isScanning}
            className="w-full bg-gradient-to-r from-[#FCA3BA] to-[#E84D7E] text-white py-4 rounded-2xl shadow-[0_4px_20px_rgba(232,77,126,0.3)] hover:shadow-[0_6px_28px_rgba(232,77,126,0.4)] transition-all duration-300 disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {isScanning ? 'Scanning...' : 'Start Scan'}
          </motion.button>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-center text-[#A05C6E] text-sm"
          >
            ⚡ AI-fit results in under 30 seconds
          </motion.p>
        </div>
      </div>
    </div>
  );
}
import { useState } from 'react';
import { motion } from 'motion/react';
import { Heart, Share2, Gift, Sparkles } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface CommunityProps {
  onRewardsClick: () => void;
}

const userPosts = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1743617206507-447c78118622?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYW5pY3VyZWQlMjBuYWlscyUyMGJlYXV0eXxlbnwxfHx8fDE3NjI3MTIyMjh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    caption: 'Loving my new Rose Blush set! 💅',
    likes: 124,
    username: '@sarah_m',
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1737214475365-e4f06281dcf3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYWlsJTIwYXJ0JTIwZGVzaWdufGVufDF8fHx8MTc2MjY3ODE4MXww&ixlib=rb-4.1.0&q=80&w=1080',
    caption: 'Perfect fit every time ✨',
    likes: 98,
    username: '@nailqueen',
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1754799670380-17640d939e32?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaW5rJTIwbmFpbHMlMjBjbG9zZSUyMHVwfGVufDF8fHx8MTc2MjcxMjIyOXww&ixlib=rb-4.1.0&q=80&w=1080',
    caption: 'These lasted 2 weeks! 🙌',
    likes: 156,
    username: '@emily_nails',
  },
  {
    id: 4,
    image: 'https://images.unsplash.com/photo-1690749138086-7422f71dc159?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYWlsJTIwcG9saXNoJTIwaGFuZHN8ZW58MXx8fHwxNjI3MTIyMjl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    caption: 'AI-fit is a game changer 💖',
    likes: 87,
    username: '@beautylife',
  },
  {
    id: 5,
    image: 'https://images.unsplash.com/photo-1634819088706-b660a7aa48b0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMG5haWwlMjBtYW5pY3VyZXxlbnwxfHx8fDE3NjI3MTIyMzB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    caption: 'Obsessed with these colors!',
    likes: 201,
    username: '@nailart_lover',
  },
  {
    id: 6,
    image: 'https://images.unsplash.com/photo-1759935937415-49099042fa91?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwbmFpbHMlMjBkZXNpZ258ZW58MXx8fHwxNzYyNjgwMTAzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    caption: 'Elegant and easy to apply 🎀',
    likes: 143,
    username: '@chic_nails',
  },
];

export default function Community({ onRewardsClick }: CommunityProps) {
  const [likedPosts, setLikedPosts] = useState<number[]>([]);
  const [points, setPoints] = useState(450);

  const toggleLike = (postId: number) => {
    if (likedPosts.includes(postId)) {
      setLikedPosts(likedPosts.filter((id) => id !== postId));
      setPoints(points - 5);
    } else {
      setLikedPosts([...likedPosts, postId]);
      setPoints(points + 5);
    }
  };

  const handleShare = () => {
    setPoints(points + 10);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FEEBEC] to-[#FCEFE5]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#FCA3BA] via-[#E84D7E] to-[#C4536C] px-6 py-8 text-white shadow-xl relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute inset-0 opacity-20">
          {[...Array(8)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                y: [0, -15, 0],
                opacity: [0.3, 0.6, 0.3],
              }}
              transition={{
                duration: 2 + Math.random(),
                repeat: Infinity,
                delay: Math.random() * 2,
              }}
            >
              <Sparkles size={16} />
            </motion.div>
          ))}
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center relative z-10"
        >
          <h1 className="text-3xl flex items-center justify-center gap-3 mb-3" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
            Nail'd Community
            <Sparkles size={28} className="text-[#FFD9A5]" />
          </h1>
          <p className="text-white/95 text-base" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 500 }}>
            Share your looks and earn rewards
          </p>
        </motion.div>
      </div>

      {/* Points Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mx-6 -mt-6 bg-[#FCEFE5] rounded-2xl p-4 shadow-lg mb-6"
      >
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Gift className="text-[#FFD9A5]" size={24} />
            <span className="text-[#C4536C]">Your Points</span>
          </div>
          <span className="text-[#E84D7E] text-xl">{points}</span>
        </div>
        
        {/* Progress bar */}
        <div className="w-full bg-white rounded-full h-3 mb-2 overflow-hidden">
          <motion.div
            className="bg-gradient-to-r from-[#FCA3BA] to-[#E84D7E] h-full rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${(points / 1000) * 100}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
        
        <div className="flex items-center justify-between text-xs text-[#A05C6E]">
          <span>Earn points for sharing, posting, or referring friends!</span>
          <button onClick={onRewardsClick} className="text-[#E84D7E] underline">
            Redeem
          </button>
        </div>
      </motion.div>

      {/* Feed Grid */}
      <div className="px-6">
        <div className="grid grid-cols-2 gap-4">
          {userPosts.map((post, index) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-lg transition-shadow"
            >
              {/* Image */}
              <div className="relative aspect-square overflow-hidden group">
                <ImageWithFallback
                  src={post.image}
                  alt={post.caption}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                {/* Sparkle overlay on hover */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-start justify-end p-2">
                  <Sparkles className="text-[#FFD9A5]" size={20} />
                </div>
              </div>

              {/* Post info */}
              <div className="p-3">
                <p className="text-xs text-[#A05C6E] mb-2">{post.username}</p>
                <p className="text-sm text-[#C4536C] mb-3 line-clamp-2">
                  {post.caption}
                </p>

                {/* Actions */}
                <div className="flex items-center justify-between">
                  <button
                    onClick={() => toggleLike(post.id)}
                    className="flex items-center gap-1 transition-transform active:scale-90"
                  >
                    <Heart
                      size={18}
                      className={likedPosts.includes(post.id) ? 'text-[#E84D7E]' : 'text-[#C4536C]'}
                      fill={likedPosts.includes(post.id) ? '#E84D7E' : 'none'}
                    />
                    <span className="text-xs text-[#A05C6E]">
                      {post.likes + (likedPosts.includes(post.id) ? 1 : 0)}
                    </span>
                  </button>

                  <button
                    onClick={handleShare}
                    className="flex items-center gap-1 transition-transform active:scale-90"
                  >
                    <Share2 size={18} className="text-[#C4536C]" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Floating action hint */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1 }}
        className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-[#E84D7E] text-white px-6 py-3 rounded-full shadow-lg text-sm"
      >
        Swipe up for more inspiration
      </motion.div>
    </div>
  );
}
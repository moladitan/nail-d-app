import { motion } from 'motion/react';
import { Sparkles } from 'lucide-react';
import logoImage from 'figma:asset/f4ebe04187e1e9fce3c04bbc6dd8c71426601b82.png';

interface OnboardingIntroProps {
  onNext: () => void;
}

export default function OnboardingIntro({ onNext }: OnboardingIntroProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-between bg-gradient-to-b from-[#FCA3BA] via-[#E84D7E] to-[#C4536C] px-8 py-12 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Radial gradient overlay for depth */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(252,163,186,0.3)_0%,transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,rgba(196,83,108,0.3)_0%,transparent_50%)]" />
        
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.2, 0.7, 0.2],
              scale: [0.8, 1.3, 0.8],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
              ease: "easeInOut"
            }}
          >
            <Sparkles className="text-white/40" size={14 + Math.random() * 20} />
          </motion.div>
        ))}
      </div>

      {/* Status bar spacer */}
      <div className="w-full h-12" />

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center z-10">
        {/* Logo */}
        <motion.div
          initial={{ opacity: 0, scale: 0.7, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ 
            duration: 1, 
            ease: [0.16, 1, 0.3, 1],
            type: "spring",
            stiffness: 100
          }}
          className="mb-14 relative"
        >
          {/* Glow effect behind logo */}
          <div className="absolute inset-0 blur-3xl bg-white/30 scale-150" />
          <img 
            src={logoImage} 
            alt="Nail'd Logo" 
            className="relative w-60 h-auto drop-shadow-2xl"
          />
        </motion.div>

        {/* Tagline */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="text-center space-y-4 mb-10"
        >
          <h1 className="text-white text-2xl tracking-tight px-8 drop-shadow-lg" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 600 }}>
            For nails as resilient as you.
          </h1>
          <p className="text-white/95 text-base px-8 drop-shadow-md" style={{ fontFamily: 'Nunito, sans-serif' }}>
            AI-powered custom fit press-ons
          </p>
        </motion.div>

        {/* Feature highlights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col gap-3 mb-12 w-full max-w-sm"
        >
          {[
            { icon: '📸', text: 'Scan & get your perfect fit' },
            { icon: '🎨', text: 'Customize your unique style' },
            { icon: '✨', text: 'Premium quality, delivered' }
          ].map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ 
                duration: 0.7, 
                delay: 0.8 + index * 0.12,
                ease: [0.16, 1, 0.3, 1]
              }}
              whileHover={{ scale: 1.03, x: 5 }}
              className="flex items-center gap-4 bg-white/25 backdrop-blur-lg rounded-2xl px-6 py-4 border border-white/40 shadow-[0_8px_32px_rgba(0,0,0,0.1)]"
            >
              <span className="text-3xl drop-shadow-sm">{feature.icon}</span>
              <span className="text-white text-base drop-shadow-sm" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 500 }}>
                {feature.text}
              </span>
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* CTA Button */}
      <motion.button
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, delay: 1.1, ease: [0.16, 1, 0.3, 1] }}
        whileHover={{ scale: 1.03, boxShadow: "0 20px 60px rgba(0,0,0,0.25)" }}
        whileTap={{ scale: 0.97 }}
        onClick={onNext}
        className="w-full bg-white text-[#E84D7E] py-5 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.2)] z-10 transition-all"
        style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700, letterSpacing: '0.02em' }}
      >
        Let's Find Your Perfect Fit
      </motion.button>

      {/* Bottom safe area */}
      <div className="w-full h-6" />
    </div>
  );
}
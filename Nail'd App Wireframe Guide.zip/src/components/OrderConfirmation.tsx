import { useState } from 'react';
import { motion } from 'motion/react';
import { Package, CheckCircle2, Sparkles } from 'lucide-react';

interface OrderConfirmationProps {
  selectedDesign: {
    color: string;
    finish: string;
    colorName: string;
  };
  onNext: () => void;
}

export default function OrderConfirmation({ selectedDesign, onNext }: OrderConfirmationProps) {
  const [isOrdered, setIsOrdered] = useState(false);

  const handleOrder = () => {
    setIsOrdered(true);
    setTimeout(() => {
      onNext();
    }, 2000);
  };

  if (isOrdered) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-[#FEEBEC] to-[#FCEFE5] px-6">
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", duration: 0.6 }}
          className="text-center"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-[#FCA3BA] to-[#E84D7E] rounded-full mb-6 shadow-2xl"
          >
            <CheckCircle2 size={48} className="text-white" strokeWidth={3} />
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-2xl text-[#C4536C] mb-3"
            style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 600 }}
          >
            Order Placed!
          </motion.h2>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="flex items-center justify-center gap-2 text-[#A05C6E]"
            style={{ fontFamily: 'Nunito, sans-serif' }}
          >
            <Sparkles className="text-[#FFD9A5]" size={18} />
            <p>Your nails are on their way!</p>
            <Sparkles className="text-[#FFD9A5]" size={18} />
          </motion.div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-[#FEEBEC] to-[#FCEFE5] px-6 py-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="text-center mb-8 mt-6"
      >
        <h1 className="text-3xl text-[#C4536C] mb-3" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700 }}>
          Your Custom Kit
        </h1>
        <p className="text-[#A05C6E] text-base" style={{ fontFamily: 'Nunito, sans-serif' }}>
          Review and confirm your order
        </p>
      </motion.div>

      {/* Kit Preview Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="flex-1 flex items-center justify-center"
      >
        <div className="bg-white/80 backdrop-blur-md rounded-3xl p-8 shadow-[0_10px_60px_rgba(196,83,108,0.15)] border border-[#FCA3BA]/30 max-w-md w-full">
          {/* Kit Box Illustration */}
          <div className="bg-gradient-to-br from-white to-[#FEEBEC] rounded-3xl p-8 mb-6 relative overflow-hidden shadow-inner">
            <div className="absolute top-3 right-3">
              <motion.div
                animate={{
                  rotate: [0, 15, -15, 0],
                  scale: [1, 1.2, 1],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                }}
              >
                <Sparkles className="text-[#FFD9A5]" size={28} />
              </motion.div>
            </div>
            <Package size={100} className="text-[#FCA3BA] mx-auto mb-6 drop-shadow-lg" strokeWidth={1.5} />
            
            {/* 10 nail swatches */}
            <div className="flex justify-center gap-1.5 mb-3">
              {[...Array(10)].map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + i * 0.05 }}
                  className="w-6 h-10 rounded-full border-2 border-[#8B4C5C] shadow-md"
                  style={{ backgroundColor: selectedDesign.color }}
                />
              ))}
            </div>
            <p className="text-center text-sm text-[#A05C6E] mt-3" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>
              {selectedDesign.colorName} - {selectedDesign.finish}
            </p>
          </div>

          {/* Kit Contents */}
          <div className="space-y-4">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3, duration: 0.5 }}
              className="flex items-center gap-3 p-3 bg-[#FEEBEC]/50 rounded-xl"
            >
              <CheckCircle2 className="text-[#E84D7E]" size={22} strokeWidth={2.5} />
              <p className="text-[#C4536C]" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>AI-fit set (pre-labeled by finger)</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="flex items-center gap-3 p-3 bg-[#FEEBEC]/50 rounded-xl"
            >
              <CheckCircle2 className="text-[#E84D7E]" size={22} strokeWidth={2.5} />
              <p className="text-[#C4536C]" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>Dual adhesive tabs</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5, duration: 0.5 }}
              className="flex items-center gap-3 p-3 bg-[#FEEBEC]/50 rounded-xl"
            >
              <CheckCircle2 className="text-[#E84D7E]" size={22} strokeWidth={2.5} />
              <p className="text-[#C4536C]" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>Prep pads + remover sachets</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6, duration: 0.5 }}
              className="flex items-center gap-3 p-3 bg-[#FEEBEC]/50 rounded-xl"
            >
              <CheckCircle2 className="text-[#E84D7E]" size={22} strokeWidth={2.5} />
              <p className="text-[#C4536C]" style={{ fontFamily: 'Nunito, sans-serif', fontWeight: 600 }}>Pink storage case</p>
            </motion.div>
          </div>
        </div>
      </motion.div>

      {/* CTA and Footer */}
      <div className="w-full max-w-md mx-auto space-y-4 mt-8">
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.6 }}
          whileHover={{ scale: 1.02, boxShadow: "0 8px 32px rgba(232,77,126,0.45)" }}
          whileTap={{ scale: 0.98 }}
          onClick={handleOrder}
          className="w-full bg-gradient-to-r from-[#FCA3BA] to-[#E84D7E] text-white py-5 rounded-2xl shadow-[0_6px_24px_rgba(232,77,126,0.35)] transition-all"
          style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700, letterSpacing: '0.02em' }}
        >
          Place My Order
        </motion.button>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="text-center text-[#A05C6E] text-sm"
          style={{ fontFamily: 'Nunito, sans-serif' }}
        >
          Track your delivery in My Nails.
        </motion.p>
      </div>
    </div>
  );
}
import { ReactNode } from 'react';
import { motion } from 'motion/react';

interface IPhoneFrameProps {
  children: ReactNode;
}

export default function IPhoneFrame({ children }: IPhoneFrameProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-slate-100 to-slate-200 flex items-center justify-center p-4 sm:p-8">
      {/* iPhone 16 Frame */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="relative"
      >
        {/* Device Shadow */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-300/50 to-slate-700/50 blur-3xl scale-95 -z-10" />
        
        {/* iPhone Bezel */}
        <div className="relative bg-gradient-to-b from-[#0f0f0f] via-[#1a1a1a] to-[#0a0a0a] rounded-[3.75rem] p-[10px] shadow-2xl ring-1 ring-white/5">
          {/* Inner Screen Frame */}
          <div className="relative bg-black rounded-[3.3rem] overflow-hidden">
            {/* Dynamic Island */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[125px] h-[37px] bg-black rounded-b-[22px] z-50 flex items-center justify-center">
              <div className="w-[95px] h-[26px] bg-[#0a0a0a] rounded-[20px] flex items-center justify-center gap-2.5 shadow-inner">
                <div className="w-[15px] h-[15px] rounded-full bg-gradient-to-br from-[#1a1a2e] to-[#0f0f1a] border border-slate-800/50 shadow-lg" />
                <div className="w-[9px] h-[9px] rounded-full bg-gradient-to-br from-[#2a2a3e] to-[#1a1a2e] shadow-inner" />
              </div>
            </div>

            {/* Screen Content - iPhone 16 dimensions */}
            <div className="relative w-[393px] h-[852px] bg-white overflow-hidden">
              <div className="absolute inset-0 overflow-y-auto overflow-x-hidden">
                {children}
              </div>
              
              {/* Home Indicator */}
              <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-[140px] h-[5px] bg-gradient-to-r from-transparent via-slate-800 to-transparent rounded-full opacity-70 z-50" />
            </div>
          </div>

          {/* Side Buttons - Volume */}
          <div className="absolute left-[-3px] top-[110px] w-[3px] h-[32px] bg-gradient-to-b from-[#3a3a3a] via-[#2a2a2a] to-[#1a1a1a] rounded-l-sm shadow-inner" />
          <div className="absolute left-[-3px] top-[155px] w-[3px] h-[58px] bg-gradient-to-b from-[#3a3a3a] via-[#2a2a2a] to-[#1a1a1a] rounded-l-sm shadow-inner" />
          <div className="absolute left-[-3px] top-[225px] w-[3px] h-[58px] bg-gradient-to-b from-[#3a3a3a] via-[#2a2a2a] to-[#1a1a1a] rounded-l-sm shadow-inner" />
          
          {/* Side Button - Power */}
          <div className="absolute right-[-3px] top-[175px] w-[3px] h-[90px] bg-gradient-to-b from-[#3a3a3a] via-[#2a2a2a] to-[#1a1a1a] rounded-r-sm shadow-inner" />
          
          {/* Action Button (new in iPhone 16) */}
          <div className="absolute left-[-3px] top-[95px] w-[3px] h-[12px] bg-gradient-to-b from-[#4a4a4a] via-[#3a3a3a] to-[#2a2a2a] rounded-l-sm shadow-inner" />
        </div>
      </motion.div>
    </div>
  );
}